import { registerRootComponent } from "expo";
import App from "./App";

// register the main component
registerRootComponent(App);
