export const BACKEND_URL = "http://localhost:8000";
