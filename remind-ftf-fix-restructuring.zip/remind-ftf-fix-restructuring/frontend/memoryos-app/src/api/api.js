// src/api/api.js
import axios from "axios";
import { BACKEND_URL } from "../config";

const api = axios.create({ baseURL: BACKEND_URL });

// Health
export const getHealth = () => api.get("/health");

// Upload flow
export const getUploadUrl = (filename) =>
  api.post("/upload_url", { filename });

export async function uploadFileToPresignedPost(uploadUrl, fields, file) {
  const formData = new FormData();
  Object.entries(fields).forEach(([k, v]) => formData.append(k, v));
  formData.append("file", {
    uri: file.uri,
    name: file.name || "upload.jpg",
    type: file.type || "image/jpeg",
  });

  const res = await fetch(uploadUrl, { method: "POST", body: formData });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`S3 upload failed: ${res.status} ${text}`);
  }
  return true;
}

// Memories
export const createMemory = (payload) => api.post("/memories", payload);
export const getAllMemories = () =>
  api.get("/all/memories", { headers: { Accept: "application/json" } });

// Search
export const searchMemories = (query, k = 10) =>
  api.post("/search", { query, k });

// Zoom sync
export const syncZoom = () => api.post("/sync_zoom_meetings");

// Tasks endpoints (added)
export const getActiveTasks = () => api.get("/tasks/active");
// Note: complete path is POST /tasks/{id}/complete
export const completeTask = (taskId) => api.post(`/tasks/${taskId}/complete`);
// Update task (PUT /tasks/{id})
export const updateTask = (taskId, payload) => api.put(`/tasks/${taskId}`, payload);

// Created tasks (placeholder - your backend may have a different route)
export const getCreatedTasks = () => api.get("/tasks/created");

export const getPendingApprovalTasks = () => api.get("/tasks/pending-approval");
export const approveTask = (taskId) => api.post(`/tasks/${taskId}/approve`);
export const disapproveTask = (taskId) => api.post(`/tasks/${taskId}/disapprove`);