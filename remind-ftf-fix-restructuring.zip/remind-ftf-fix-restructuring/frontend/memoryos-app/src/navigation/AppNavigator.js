import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import MemoryCaptureScreen from "../screens/MemoryCaptureScreen";
import MemoriesScreen from "../screens/MemoriesScreen";
import SearchScreen from "../screens/SearchScreen";
import TasksScreen from "../screens/TasksScreen";

const Tab = createBottomTabNavigator();

export default function AppNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          if (route.name === "Capture") {
            iconName = "camera-outline";
          } else if (route.name === "Memories") {
            iconName = "images-outline";
          } else if (route.name === "Search") {
            iconName = "search-outline";
          } else if (route.name === "Tasks") {
            iconName = "list-outline";
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "tomato",
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen name="Capture" component={MemoryCaptureScreen} />
      <Tab.Screen name="Memories" component={MemoriesScreen} />
      <Tab.Screen name="Search" component={SearchScreen} />
      <Tab.Screen name="Tasks" component={TasksScreen} />
    </Tab.Navigator>
  );
}