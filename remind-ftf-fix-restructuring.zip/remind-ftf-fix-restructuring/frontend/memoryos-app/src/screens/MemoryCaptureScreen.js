import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import {
  getUploadUrl,
  uploadFileToPresignedPost,
  createMemory,
} from "../api/api";
import { Ionicons } from "@expo/vector-icons";
import LottieView from "lottie-react-native";

export default function MemoryCaptureScreen() {
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [image, setImage] = useState(null);
  const [uploadMeta, setUploadMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [createdMemory, setCreatedMemory] = useState(null);

  async function pickImage() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (!result.canceled) {
      const img = result.assets[0];
      setImage(img);

      // Step 1: get presigned URL immediately
      const filename = img.uri.split("/").pop();
      try {
        const res = await getUploadUrl(filename);
        setUploadMeta({ ...res.data, filename });
        // Step 2: upload to S3
        await uploadFileToPresignedPost(res.data.upload_url, res.data.fields, {
          uri: img.uri,
          name: filename,
          type: "image/jpeg",
        });
      } catch (e) {
        alert("Image upload failed: " + e.message);
      }
    }
  }

  async function handleCreateMemory() {
    try {
      setLoading(true);
      setCreatedMemory(null);

      // Decide modalities
      let modalities = [];
      if (title || summary) modalities.push("text");
      if (image) modalities.push("image");

      // Build payload
      const payload = {
        title: title || null,
        summary: summary || null,
        modalities,
        media: [],
      };

      if (image && uploadMeta) {
        payload.media.push({
          type: "image",
          url: uploadMeta.file_url,
          filename: uploadMeta.filename,
          content_type: "image/jpeg",
        });
      }

      const res = await createMemory(payload);
      setCreatedMemory(res.data);
    } catch (e) {
      alert("Failed to create memory: " + e.message);
    } finally {
      setLoading(false);
    }
  }

  function handleRefresh() {
    setTitle("");
    setSummary("");
    setImage(null);
    setUploadMeta(null);
    setCreatedMemory(null);
  }

  return (
    <ScrollView style={styles.container}>
      {/* Refresh Button */}
      <TouchableOpacity style={styles.refreshButton} onPress={handleRefresh}>
        <Ionicons name="refresh-outline" size={20} color="white" />
        <Text style={styles.refreshButtonText}>Refresh</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Create a Memory</Text>

      {/* Title Input */}
      <TextInput
        placeholder="Title (optional)"
        placeholderTextColor="#374151" // darker grey
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />

      {/* Summary Input */}
      <TextInput
        placeholder="Summary (optional)"
        placeholderTextColor="#374151" // darker grey
        value={summary}
        onChangeText={setSummary}
        style={[styles.input, { height: 80 }]}
        multiline
      />

      {/* Image Picker */}
      <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
        <Ionicons name="image-outline" size={20} color="white" />
        <Text style={styles.imageButtonText}>
          {image ? "Change Image" : "Pick an Image"}
        </Text>
      </TouchableOpacity>

      {image && (
        <Image
          source={{ uri: image.uri }}
          style={styles.previewImage}
          resizeMode="cover"
        />
      )}

      {/* Create Memory Button */}
      <TouchableOpacity
        style={styles.createButton}
        onPress={handleCreateMemory}
        disabled={loading}
      >
        {loading ? (
          <LottieView
            source={require("../../assets/animations/refresh.json")}
            autoPlay
            loop
            style={styles.loader}
          />
        ) : (
          <>
            <Ionicons name="add-circle-outline" size={22} color="white" />
            <Text style={styles.createButtonText}>Create Memory</Text>
          </>
        )}
      </TouchableOpacity>

      {/* Created Memory Display */}
      {createdMemory && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>✅ Memory Created!</Text>
          <Text>ID: {createdMemory.id}</Text>
          <Text>Title: {createdMemory.title || "-"}</Text>
          <Text>Summary: {createdMemory.summary || "-"}</Text>
          <Text>Status: {createdMemory.status}</Text>
          <Text>
            Captured At: {new Date(createdMemory.captured_at).toLocaleString()}
          </Text>

          {createdMemory.media &&
            createdMemory.media.map((m, i) =>
              m.url ? (
                <Image
                  key={i}
                  source={{ uri: m.url }}
                  style={styles.cardImage}
                  resizeMode="cover"
                />
              ) : null
            )}

          {createdMemory.modalities && (
            <Text>Modalities: {createdMemory.modalities.join(", ")}</Text>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f9fafb" },
  refreshButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#6b7280",
    padding: 8,
    borderRadius: 8,
    alignSelf: "flex-end",
    marginBottom: 12,
  },
  refreshButtonText: { color: "white", marginLeft: 6, fontWeight: "600" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, textAlign: "center" },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
    backgroundColor: "white",
    fontSize: 15,
    color: "black", // darker text
  },
  imageButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#2563eb",
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
    justifyContent: "center",
  },
  imageButtonText: { color: "white", marginLeft: 6, fontWeight: "600" },
  previewImage: {
    width: "100%",
    height: 200,
    borderRadius: 8,
    marginBottom: 12,
  },
  createButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#4f46e5",
    padding: 12,
    borderRadius: 10,
    justifyContent: "center",
  },
  createButtonText: { color: "white", marginLeft: 8, fontWeight: "600" },
  loader: { width: 30, height: 30 },
  card: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  cardTitle: { fontWeight: "bold", marginBottom: 8, fontSize: 16 },
  cardImage: { width: "100%", height: 180, borderRadius: 10, marginVertical: 8 },
});