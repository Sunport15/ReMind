import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { searchMemories } from "../api/api";
import { Ionicons } from "@expo/vector-icons";
import LottieView from "lottie-react-native";
import { useNavigation } from "@react-navigation/native";

export default function SearchScreen() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState(null);
  const [searched, setSearched] = useState(false);

  const navigation = useNavigation();

  async function onSearch() {
    if (!q.trim()) {
      alert("Enter a query to search");
      return;
    }

    setLoading(true);
    setSearched(true);
    try {
      const res = await searchMemories(q.trim());
      setResults(res.data.results || []);
      setMeta({
        query: res.data.query,
        total: res.data.total,
        metadata: res.data.search_metadata,
      });
    } catch (e) {
      alert(e.message || JSON.stringify(e));
    } finally {
      setLoading(false);
    }
  }

  const renderResultCard = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("Memories", { memoryId: item.id })}
    >
      <Text style={styles.title}>{item.title || "Untitled Memory"}</Text>
      {item.summary ? <Text style={styles.summary}>{item.summary}</Text> : null}

      {item.enhanced_content ? (
        <Text style={styles.field}>
          <Text style={styles.fieldLabel}>Enhanced Content: </Text>
          {item.enhanced_content}
        </Text>
      ) : null}

      {item.ai_descriptions ? (
        <Text style={styles.field}>
          <Text style={styles.fieldLabel}>AI Description: </Text>
          {item.ai_descriptions}
        </Text>
      ) : null}

      {item.generated_content ? (
        <Text style={styles.field}>
          <Text style={styles.fieldLabel}>Generated Content: </Text>
          {item.generated_content}
        </Text>
      ) : null}
    </TouchableOpacity>
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      {/* Search bar */}
      <View style={styles.searchRow}>
        <TextInput
          placeholder="Search memories..."
          placeholderTextColor="#374151"
          value={q}
          onChangeText={setQ}
          style={styles.input}
          returnKeyType="search"
          onSubmitEditing={onSearch}
        />
        <TouchableOpacity style={styles.searchButton} onPress={onSearch}>
          {loading ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.searchAnim}
            />
          ) : (
            <Ionicons name="search-outline" size={22} color="white" />
          )}
        </TouchableOpacity>
      </View>

      {/* Meta info */}
      {meta && (
        <View style={styles.metaBox}>
          <Text style={styles.metaTitle}>Search Query: {meta.query}</Text>
          <Text style={styles.metaInfo}>Total Results: {meta.total}</Text>
          <Text style={styles.metaInfo}>
            Service: {meta.metadata?.service_used}
          </Text>
        </View>
      )}

      {/* Results */}
      {searched && !loading && results.length === 0 ? (
        <View style={styles.noResults}>
          <Ionicons name="search-outline" size={50} color="#9ca3af" />
          <Text style={styles.noResultsText}>No results found</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item, index) => item.id || index.toString()}
          renderItem={renderResultCard}
          contentContainerStyle={{ paddingBottom: 30 }}
        />
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: "#f9fafb" },
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: "white",
    fontSize: 15,
    color: "black",
  },
  searchButton: {
    marginLeft: 8,
    backgroundColor: "#4f46e5",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  searchAnim: { width: 28, height: 28 },
  metaBox: {
    backgroundColor: "#eef2ff",
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
  },
  metaTitle: { fontWeight: "bold", marginBottom: 4, color: "#111827" },
  metaInfo: { fontSize: 12, color: "#374151" },
  card: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
    color: "#111827",
  },
  summary: { fontSize: 14, marginBottom: 6, color: "#374151" },
  field: { fontSize: 13, marginBottom: 4, color: "#1f2937" },
  fieldLabel: { fontWeight: "600", color: "#2563eb" },
  noResults: {
    alignItems: "center",
    marginTop: 50,
  },
  noResultsText: {
    marginTop: 8,
    fontSize: 16,
    color: "#6b7280",
  },
});