import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Animated,
  Modal,
  TextInput,
  Alert,
  Platform,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import LottieView from "lottie-react-native";

import {
  getActiveTasks,
  completeTask,
  updateTask,
  getPendingApprovalTasks,
  approveTask,
  disapproveTask,
} from "../api/api";

export default function TasksScreen() {
  const [activeTab, setActiveTab] = useState("active"); // 'active' | 'unapproved'

  // ---- Active tasks state ----
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [completingId, setCompletingId] = useState(null);

  // ---- Unapproved tasks state ----
  const [unapprovedTasks, setUnapprovedTasks] = useState([]);
  const [unapprovedLoading, setUnapprovedLoading] = useState(false);
  const [refreshingUnapproved, setRefreshingUnapproved] = useState(false);
  const [processingId, setProcessingId] = useState(null);

  // ---- Editing modal state ----
  const [editingTask, setEditingTask] = useState(null);
  const [editDueDate, setEditDueDate] = useState("");
  const [editPriority, setEditPriority] = useState("");
  const [editLoading, setEditLoading] = useState(false);

  // highlight
  const [highlightedId, setHighlightedId] = useState(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  // -------- Fetchers --------
  async function fetchActiveTasks() {
    setLoading(true);
    try {
      const res = await getActiveTasks();
      setTasks(res.data || []);
    } catch (err) {
      console.log("Error fetching active tasks:", err.message);
      Alert.alert("Error", "Failed to load active tasks");
    } finally {
      setLoading(false);
    }
  }

  async function fetchUnapprovedTasks() {
    setUnapprovedLoading(true);
    try {
      const res = await getPendingApprovalTasks();
      setUnapprovedTasks(res.data || []);
    } catch (err) {
      console.log("Error fetching unapproved tasks:", err.message);
      Alert.alert("Error", "Failed to load unapproved tasks");
    } finally {
      setUnapprovedLoading(false);
    }
  }

  // toggle loader refreshers
  async function handleRefreshActive() {
    setRefreshing(true);
    await fetchActiveTasks();
    setTimeout(() => setRefreshing(false), 600);
  }

  async function handleRefreshUnapproved() {
    setRefreshingUnapproved(true);
    await fetchUnapprovedTasks();
    setTimeout(() => setRefreshingUnapproved(false), 600);
  }

  useFocusEffect(
    useCallback(() => {
      if (activeTab === "active") {
        fetchActiveTasks();
      } else {
        fetchUnapprovedTasks();
      }
    }, [activeTab])
  );

  // -------- Actions --------
  async function handleComplete(taskId) {
    try {
      setCompletingId(taskId);
      const res = await completeTask(taskId);
      Alert.alert("Task completed", res?.data?.message || "Task completed");
      await fetchActiveTasks();
    } catch (err) {
      console.log("Complete error:", err);
      Alert.alert("Error", "Failed to complete task");
    } finally {
      setCompletingId(null);
    }
  }

  function openEditModal(task) {
    setEditingTask(task);
    setEditDueDate(task.due_date || "");
    setEditPriority(task.priority || "");
  }

  function closeEditModal() {
    setEditingTask(null);
    setEditDueDate("");
    setEditPriority("");
  }

  async function handleSaveEdit() {
    if (!editingTask) return;
    setEditLoading(true);
    try {
      const payload = {};
      if (editDueDate) payload.due_date = editDueDate;
      if (editPriority) payload.priority = editPriority;

      const res = await updateTask(editingTask.id, payload);
      const updated = res?.data;
      if (updated) {
        setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
      }
      Alert.alert("Updated", "Task updated successfully");
      closeEditModal();
    } catch (err) {
      console.log("Update error:", err);
      Alert.alert("Error", "Failed to update task");
    } finally {
      setEditLoading(false);
    }
  }

  async function handleApprove(taskId) {
    try {
      setProcessingId(taskId);
      const res = await approveTask(taskId);
      Alert.alert("Approved", res?.data?.message || "Task approved");
      await fetchUnapprovedTasks();
    } catch (err) {
      console.log("Approve error:", err);
      Alert.alert("Error", "Failed to approve task");
    } finally {
      setProcessingId(null);
    }
  }

  async function handleDisapprove(taskId) {
    try {
      setProcessingId(taskId);
      const res = await disapproveTask(taskId);
      Alert.alert("Disapproved", res?.data?.message || "Task disapproved");
      await fetchUnapprovedTasks();
    } catch (err) {
      console.log("Disapprove error:", err);
      Alert.alert("Error", "Failed to disapprove task");
    } finally {
      setProcessingId(null);
    }
  }

  // -------- Renderers --------
  const renderTaskCard = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.rowTop}>
        <Text style={styles.taskTitle}>{item.title}</Text>
        <Text style={styles.category}>{(item.category || "").toUpperCase()}</Text>
      </View>
      {item.description ? <Text style={styles.desc}>{item.description}</Text> : null}

      <View style={styles.metaRow}>
        <Text style={styles.metaLabel}>Due:</Text>
        <Text style={styles.metaValue}>
          {item.due_date ? new Date(item.due_date).toLocaleString() : "-"}
        </Text>
        <Text style={[styles.metaLabel, { marginLeft: 12 }]}>Priority:</Text>
        <Text style={styles.metaValue}>{item.priority || "-"}</Text>
      </View>

      {item.extraction_metadata ? (
        <View style={styles.extractionBox}>
          <Text style={styles.extractionTitle}>Extraction</Text>
          <Text>Method: {item.extraction_metadata.extraction_method}</Text>
          <Text>
            Extracted At:{" "}
            {new Date(item.extraction_metadata.extracted_at).toLocaleString()}
          </Text>
          <Text>Reasoning: {item.extraction_metadata.reasoning}</Text>
          {item.extraction_metadata.original_memory_title ? (
            <Text>Source: {item.extraction_metadata.original_memory_title}</Text>
          ) : null}
        </View>
      ) : null}

      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: "#10b981" }]}
          onPress={() => handleComplete(item.id)}
          disabled={completingId === item.id}
        >
          {completingId === item.id ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.btnAnim}
            />
          ) : (
            <>
              <Ionicons name="checkmark-done-outline" size={18} color="white" />
              <Text style={styles.btnText}>Complete</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.btn, { backgroundColor: "#3b82f6" }]}
          onPress={() => openEditModal(item)}
        >
          <Ionicons name="pencil-outline" size={18} color="white" />
          <Text style={styles.btnText}>Edit</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderUnapprovedCard = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.rowTop}>
        <Text style={styles.taskTitle}>{item.title}</Text>
        <Text style={styles.category}>{(item.category || "").toUpperCase()}</Text>
      </View>
      <Text style={styles.desc}>{item.description}</Text>
      <View style={styles.metaRow}>
        <Text style={styles.metaLabel}>Due:</Text>
        <Text style={styles.metaValue}>
          {item.due_date ? new Date(item.due_date).toLocaleString() : "-"}
        </Text>
        <Text style={[styles.metaLabel, { marginLeft: 12 }]}>Priority:</Text>
        <Text style={styles.metaValue}>{item.priority || "-"}</Text>
      </View>
      {item.extraction_metadata ? (
        <View style={styles.extractionBox}>
          <Text style={styles.extractionTitle}>Extraction</Text>
          <Text>Reasoning: {item.extraction_metadata.reasoning}</Text>
          <Text>Source: {item.extraction_metadata.original_memory_title}</Text>
        </View>
      ) : null}

      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: "#10b981" }]}
          onPress={() => handleApprove(item.id)}
          disabled={processingId === item.id}
        >
          {processingId === item.id ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.btnAnim}
            />
          ) : (
            <>
              <Ionicons name="checkmark-circle-outline" size={18} color="white" />
              <Text style={styles.btnText}>Approve</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.btn, { backgroundColor: "#ef4444" }]}
          onPress={() => handleDisapprove(item.id)}
          disabled={processingId === item.id}
        >
          {processingId === item.id ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.btnAnim}
            />
          ) : (
            <>
              <Ionicons name="close-circle-outline" size={18} color="white" />
              <Text style={styles.btnText}>Disapprove</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );

  // -------- UI --------
  return (
    <View style={styles.container}>
      {/* Toggle header */}
      <View style={styles.toggleRow}>
        <TouchableOpacity
          style={[styles.toggleBtn, activeTab === "active" && styles.toggleBtnActive]}
          onPress={() => setActiveTab("active")}
        >
          <Text
            style={[styles.toggleText, activeTab === "active" && styles.toggleTextActive]}
          >
            Active Tasks
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.toggleBtn,
            activeTab === "unapproved" && styles.toggleBtnActive,
          ]}
          onPress={() => setActiveTab("unapproved")}
        >
          <Text
            style={[
              styles.toggleText,
              activeTab === "unapproved" && styles.toggleTextActive,
            ]}
          >
            Unapproved Tasks
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === "active" ? (
        <View style={{ flex: 1 }}>
          <View style={styles.toolbar}>
            <TouchableOpacity style={styles.toolbarButton} onPress={handleRefreshActive}>
              {refreshing ? (
                <LottieView
                  source={require("../../assets/animations/refresh.json")}
                  autoPlay
                  loop
                  style={styles.refreshAnim}
                />
              ) : (
                <>
                  <Ionicons name="refresh-outline" size={18} color="white" />
                  <Text style={styles.toolbarText}>Refresh</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
          {loading ? (
            <ActivityIndicator size="large" color="#4f46e5" style={{ marginTop: 40 }} />
          ) : tasks.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="list-outline" size={56} color="#9ca3af" />
              <Text style={styles.emptyText}>No active tasks</Text>
            </View>
          ) : (
            <FlatList
              data={tasks}
              keyExtractor={(item) => item.id}
              renderItem={renderTaskCard}
              contentContainerStyle={{ paddingBottom: 24 }}
              onRefresh={handleRefreshActive}
              refreshing={refreshing}
            />
          )}
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <View style={styles.toolbar}>
            <TouchableOpacity
              style={styles.toolbarButton}
              onPress={handleRefreshUnapproved}
            >
              {refreshingUnapproved ? (
                <LottieView
                  source={require("../../assets/animations/refresh.json")}
                  autoPlay
                  loop
                  style={styles.refreshAnim}
                />
              ) : (
                <>
                  <Ionicons name="refresh-outline" size={18} color="white" />
                  <Text style={styles.toolbarText}>Refresh</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
          {unapprovedLoading ? (
            <ActivityIndicator size="large" color="#4f46e5" style={{ marginTop: 40 }} />
          ) : unapprovedTasks.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="create-outline" size={56} color="#9ca3af" />
              <Text style={styles.emptyText}>No unapproved tasks</Text>
            </View>
          ) : (
            <FlatList
              data={unapprovedTasks}
              keyExtractor={(item) => item.id}
              renderItem={renderUnapprovedCard}
              contentContainerStyle={{ paddingBottom: 24 }}
              onRefresh={handleRefreshUnapproved}
              refreshing={refreshingUnapproved}
            />
          )}
        </View>
      )}

      {/* Edit Modal (Active tasks only) */}
      <Modal visible={!!editingTask} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Edit Task</Text>
            <Text style={styles.inputLabel}>Due date (ISO)</Text>
            <TextInput
              value={editDueDate}
              onChangeText={setEditDueDate}
              placeholder="2025-09-20T10:00:00"
              style={styles.modalInput}
              placeholderTextColor="#9ca3af"
            />
            <Text style={[styles.inputLabel, { marginTop: 8 }]}>Priority</Text>
            <TextInput
              value={editPriority}
              onChangeText={setEditPriority}
              placeholder="high / medium / low"
              style={styles.modalInput}
              placeholderTextColor="#9ca3af"
            />
            <View style={{ flexDirection: "row", justifyContent: "flex-end", marginTop: 12 }}>
              <TouchableOpacity
                style={[styles.modalBtn, { backgroundColor: "#6b7280" }]}
                onPress={closeEditModal}
              >
                <Text style={styles.modalBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, { backgroundColor: "#10b981", marginLeft: 8 }]}
                onPress={handleSaveEdit}
                disabled={editLoading}
              >
                {editLoading ? (
                  <LottieView
                    source={require("../../assets/animations/refresh.json")}
                    autoPlay
                    loop
                    style={{ width: 36, height: 36 }}
                  />
                ) : (
                  <Text style={styles.modalBtnText}>Save</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f9fafb", padding: 12 },
  toggleRow: { flexDirection: "row", marginBottom: 12 },
  toggleBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: "white",
    alignItems: "center",
    marginRight: 8,
  },
  toggleBtnActive: { backgroundColor: "#4f46e5" },
  toggleText: { fontWeight: "600", color: "#374151" },
  toggleTextActive: { color: "white" },

  toolbar: { flexDirection: "row", justifyContent: "flex-end", marginBottom: 8 },
  toolbarButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#4f46e5",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  toolbarText: { color: "white", marginLeft: 6, fontWeight: "600" },
  refreshAnim: { width: 36, height: 36 },

  card: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  rowTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  taskTitle: { fontSize: 16, fontWeight: "700", color: "#111827", flex: 1 },
  category: { color: "#6b7280", fontWeight: "700", marginLeft: 8 },
  desc: { color: "#374151", marginTop: 8, marginBottom: 8 },
  metaRow: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  metaLabel: { fontSize: 12, color: "#6b7280", marginRight: 4 },
  metaValue: { fontSize: 12, color: "#111827" },
  extractionBox: { marginTop: 8, padding: 8, borderRadius: 8, backgroundColor: "#eef2ff" },
  extractionTitle: { fontWeight: "700", marginBottom: 6 },
  buttonRow: { flexDirection: "row", marginTop: 10 },
  btn: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginRight: 8,
  },
  btnText: { color: "white", marginLeft: 8, fontWeight: "600" },
  btnAnim: { width: 30, height: 30 },

  empty: { alignItems: "center", marginTop: 40 },
  emptyText: { marginTop: 12, color: "#6b7280", fontSize: 16 },

  modalOverlay: {
    flex: 1,
    backgroundColor: Platform.OS === "ios" ? "rgba(0,0,0,0.35)" : "rgba(0,0,0,0.5)",
    justifyContent: "center",
    padding: 20,
  },
  modalBox: { backgroundColor: "white", borderRadius: 12, padding: 16 },
  modalTitle: { fontWeight: "700", fontSize: 16, marginBottom: 8 },
  modalInput: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 8,
    padding: 8,
    marginTop: 4,
    backgroundColor: "#fff",
  },
  inputLabel: { color: "#374151", fontWeight: "600" },
  modalBtn: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8 },
  modalBtnText: { color: "white", fontWeight: "700" },
});