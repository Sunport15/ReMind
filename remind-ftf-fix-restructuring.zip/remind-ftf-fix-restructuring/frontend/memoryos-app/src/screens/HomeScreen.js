import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Button,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from "react-native";
import { getHealth, syncZoom } from "../api/api";
import { Ionicons } from "@expo/vector-icons";
import LottieView from "lottie-react-native";
import { useNavigation } from "@react-navigation/native";

export default function HomeScreen() {
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [statusOk, setStatusOk] = useState(false);

  const [syncing, setSyncing] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigation = useNavigation();

  async function fetchHealth() {
    setLoading(true);
    try {
      const res = await getHealth();
      setHealth(res.data);
      setStatusOk(res.status === 200 || res.status === 202);
    } catch (e) {
      setHealth({ error: e.message });
      setStatusOk(false);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchHealth();
  }, []);

  async function handleSyncZoom() {
    try {
      setSyncing(true);
      setSuccess(false);

      // Wait for backend response
      await syncZoom();

      // Immediately stop syncing, show success
      setSyncing(false);
      setSuccess(true);

      // Hide success and navigate after a short flash
      setTimeout(() => {
        setSuccess(false);
        navigation.navigate("Memories");
      }, 800); // success flash <1s
    } catch (e) {
      setSyncing(false);
      alert("Zoom sync failed: " + e.message);
    }
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>MemoryOS Home</Text>

      {/* Health status */}
      <View style={styles.statusRow}>
        <TouchableOpacity onPress={fetchHealth} style={styles.statusButton}>
          <Ionicons
            name="medkit-outline"
            size={22}
            color={statusOk ? "green" : "gray"}
            style={{ marginRight: 8 }}
          />
          <Text style={styles.buttonText}>
            {loading ? "Checking..." : "Check App Health"}
          </Text>
          {statusOk && (
            <Ionicons
              name="checkmark-circle"
              size={22}
              color="green"
              style={{ marginLeft: 8 }}
            />
          )}
        </TouchableOpacity>
      </View>

      {health && (
        <View style={{ marginTop: 16 }}>
          <Button
            title={expanded ? "Hide Details" : "Show Details"}
            onPress={() => setExpanded(!expanded)}
          />
        </View>
      )}

      {expanded && health && (
        <View style={styles.detailsContainer}>
          {health.elasticsearch && (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>🔍 Elasticsearch</Text>
              <Text>
                Connected: {health.elasticsearch.connected ? "✅" : "❌"}
              </Text>
              <Text>Cluster: {health.elasticsearch.cluster}</Text>
            </View>
          )}

          {health.s3 && (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>🗄️ S3</Text>
              <Text>Bucket: {health.s3.bucket}</Text>
              <Text>Region: {health.s3.region}</Text>
              <Text>Status: {health.s3.status}</Text>
              <Text>
                Connected: {health.s3.connected ? "✅" : "❌"}
              </Text>
            </View>
          )}

          {health.services && (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>🤖 Services</Text>
              <Text>Active: {health.services.active_service}</Text>
              <Text>
                LangChain Enabled:{" "}
                {health.services.bedrock_langchain?.enabled ? "✅" : "❌"}
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Zoom sync button */}
      <TouchableOpacity style={styles.syncButton} onPress={handleSyncZoom}>
        <Ionicons name="cloud-download-outline" size={24} color="white" />
        <Text style={styles.syncButtonText}>Sync Zoom Meetings</Text>
      </TouchableOpacity>

      {/* Animations BELOW button, centered */}
      {(syncing || success) && (
        <View style={styles.animationContainer}>
          {syncing && (
            <LottieView
              source={require("../../assets/animations/zoomSync.json")}
              autoPlay
              loop
              style={styles.animation}
            />
          )}
          {success && (
            <LottieView
              source={require("../../assets/animations/successFlash.json")}
              autoPlay
              loop={false}
              style={styles.animation}
            />
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f9fafb" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, textAlign: "center" },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  statusButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#e5e7eb",
    padding: 12,
    borderRadius: 10,
  },
  buttonText: { fontSize: 16, fontWeight: "500" },
  detailsContainer: { marginTop: 20 },
  card: {
    backgroundColor: "white",
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  cardTitle: { fontWeight: "bold", marginBottom: 6 },
  syncButton: {
    marginTop: 24,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#4f46e5",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignSelf: "center",
  },
  syncButtonText: { color: "white", fontSize: 16, fontWeight: "600", marginLeft: 8 },
  animationContainer: {
    marginTop: 20,
    alignItems: "center", // center horizontally
    justifyContent: "center",
  },
  animation: {
    width: 200,
    height: 200,
  },
});
