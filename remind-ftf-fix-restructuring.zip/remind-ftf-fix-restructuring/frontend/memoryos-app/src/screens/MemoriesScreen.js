import React, { useCallback, useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Image,
  ActivityIndicator,
  TouchableOpacity,
  Animated,
} from "react-native";
import { getAllMemories, syncZoom } from "../api/api";
import {
  useFocusEffect,
  useRoute,
  useNavigation,
} from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import LottieView from "lottie-react-native";

export default function MemoriesScreen() {
  const [memories, setMemories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  const route = useRoute();
  const navigation = useNavigation();
  const flatListRef = useRef(null);
  const [highlightedId, setHighlightedId] = useState(null);
  const [pendingMemoryId, setPendingMemoryId] = useState(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  async function fetchMemories() {
    setLoading(true);
    try {
      const res = await getAllMemories();
      setMemories(res.data || []);
    } catch (e) {
      console.log("Error fetching memories:", e.message);
    } finally {
      setLoading(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      fetchMemories();
    }, [])
  );

  async function handleRefresh() {
    setRefreshing(true);
    await fetchMemories();
    setTimeout(() => setRefreshing(false), 600);
  }

  async function handleSync() {
    try {
      setSyncing(true);
      setSyncSuccess(false);

      await syncZoom();
      await fetchMemories();

      setSyncing(false);
      setSyncSuccess(true);
      setTimeout(() => setSyncSuccess(false), 800);
    } catch (e) {
      setSyncing(false);
      alert("Zoom sync failed: " + e.message);
    }
  }

  // Capture memoryId param on navigation
  useEffect(() => {
    if (route.params?.memoryId) {
      setPendingMemoryId(route.params.memoryId);
    }
  }, [route.params?.memoryId]);

  // Perform scroll + highlight once data is loaded
  useEffect(() => {
    if (
      !loading &&
      pendingMemoryId &&
      memories.length > 0 &&
      flatListRef.current
    ) {
      const index = memories.findIndex((m) => m.id === pendingMemoryId);
      if (index >= 0) {
        flatListRef.current.scrollToIndex({ index, animated: true });

        setTimeout(() => {
          setHighlightedId(pendingMemoryId);
          fadeAnim.setValue(1);
          Animated.timing(fadeAnim, {
            toValue: 0,
            duration: 2000,
            useNativeDriver: false,
          }).start(() => setHighlightedId(null));
        }, 400);

        // clear pending memoryId AFTER highlight
        setPendingMemoryId(null);
        navigation.setParams({ memoryId: undefined });
      }
    }
  }, [loading, memories, pendingMemoryId]);

  const renderMemoryCard = ({ item }) => {
    const isHighlighted = item.id === highlightedId;
    const backgroundColor = isHighlighted
      ? fadeAnim.interpolate({
          inputRange: [0, 1],
          outputRange: ["white", "#fef9c3"], // white → light yellow
        })
      : "white";

    return (
      <Animated.View style={[styles.card, { backgroundColor }]}>
        <Text style={styles.title}>{item.title || "Untitled Memory"}</Text>
        {item.summary ? (
          <Text style={styles.summary}>{item.summary}</Text>
        ) : null}
        <Text style={styles.status}>
          Status: {item.status} | Captured:{" "}
          {new Date(item.captured_at).toLocaleString()}
        </Text>
        {item.media &&
          item.media.length > 0 &&
          item.media.map((m, index) =>
            m.url ? (
              <Image
                key={index}
                source={{ uri: m.url }}
                style={styles.image}
                resizeMode="cover"
              />
            ) : null
          )}
        {item.modalities && item.modalities.length > 0 && (
          <Text style={styles.modalities}>
            Modalities: {item.modalities.join(", ")}
          </Text>
        )}
      </Animated.View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Toolbar */}
      <View style={styles.toolbar}>
        <TouchableOpacity style={styles.toolbarButton} onPress={handleRefresh}>
          {refreshing ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.refreshAnim}
            />
          ) : (
            <>
              <Ionicons name="refresh-outline" size={20} color="white" />
              <Text style={styles.toolbarText}>Refresh</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.toolbarButton} onPress={handleSync}>
          {syncing ? (
            <LottieView
              source={require("../../assets/animations/refresh.json")}
              autoPlay
              loop
              style={styles.refreshAnim}
            />
          ) : syncSuccess ? (
            <LottieView
              source={require("../../assets/animations/successFlash.json")}
              autoPlay
              loop={false}
              style={styles.refreshAnim}
            />
          ) : (
            <>
              <Ionicons name="cloud-download-outline" size={20} color="white" />
              <Text style={styles.toolbarText}>Sync Zoom</Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#4f46e5" />
      ) : (
        <FlatList
          ref={flatListRef}
          data={memories}
          keyExtractor={(item) => item.id}
          renderItem={renderMemoryCard}
          contentContainerStyle={{ paddingBottom: 20 }}
          onScrollToIndexFailed={(info) => {
            setTimeout(() => {
              flatListRef.current?.scrollToIndex({
                index: info.index,
                animated: true,
              });
            }, 500);
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: "#f9fafb" },
  toolbar: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  toolbarButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#4f46e5",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  toolbarText: { color: "white", marginLeft: 6, fontWeight: "600" },
  refreshAnim: { width: 40, height: 40 },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  title: { fontSize: 18, fontWeight: "bold", marginBottom: 6, color: "#111827" },
  summary: { fontSize: 14, marginBottom: 8, color: "#374151" },
  status: { fontSize: 12, marginBottom: 8, color: "#6b7280" },
  image: { width: "100%", height: 200, borderRadius: 10, marginBottom: 8 },
  modalities: { fontSize: 12, color: "#2563eb", fontStyle: "italic" },
});