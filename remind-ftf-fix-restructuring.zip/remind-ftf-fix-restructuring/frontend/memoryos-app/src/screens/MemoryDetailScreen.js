import { Image, ScrollView, Text } from "react-native";

export default function MemoryDetailScreen({ route }) {
  const { memory } = route.params;
  return (
    <ScrollView style={{ padding: 12 }}>
      <Text style={{ fontSize: 20, fontWeight: "bold" }}>
        {memory.title || "Untitled"}
      </Text>
      <Text style={{ marginTop: 8 }}>{memory.summary}</Text>
      {memory.media &&
        memory.media.map((m, i) =>
          m.type === "image" ? (
            <Image
              key={i}
              source={{ uri: m.url }}
              style={{ width: "100%", height: 300, marginTop: 12 }}
            />
          ) : null
        )}
    </ScrollView>
  );
}
