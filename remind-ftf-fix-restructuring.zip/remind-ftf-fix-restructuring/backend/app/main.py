from dotenv import load_dotenv 
# Load environment variables from .env file FIRST
load_dotenv()

import os
import time
import json
import random
from datetime import datetime, timedelta
from fastapi import FastAPI, BackgroundTasks, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional, Dict
import boto3
from botocore.client import Config
from elasticsearch import Elasticsearch
import mimetypes
from elasticsearch import Elasticsearch
from fastapi import Depends

# Database and models
from .database import SessionLocal, engine, Base
from .models import Memory, Task  # Add Task import
from .services.reminder_service import reminder_service

# Schemas - ADD SearchRequest here
from .schemas import (
    MemoryCreate, MemoryOut, MediaItem, SearchRequest,
    TaskCreate, TaskUpdate, TaskOut, TaskSummary  # Add Task schemas
)
from .services.task_extraction_service import task_extraction_service

# Services and integrations
from .integrations.zoom import get_zoom_meetings_with_details
# from .services.bedrock_service import bedrock_service
from .services.langchain_bedrock_service import langchain_bedrock_service
from .utils.image_utils import requests
import base64
import io
from PIL import Image
from typing import Dict, Any, Optional

def download_and_prepare_image(image_url: str) -> Dict[str, Any]:
    """Download image from URL and prepare it for Bedrock analysis."""
    try:
        print(f"📥 Downloading image from: {image_url}")
        
        # Download image
        response = requests.get(image_url, timeout=30)
        if response.status_code != 200:
            return {"error": f"Failed to download image: HTTP {response.status_code}"}
        
        # Validate image
        try:
            image = Image.open(io.BytesIO(response.content))
            print(f"📸 Image info: {image.format} {image.size} {image.mode}")
        except Exception as e:
            return {"error": f"Invalid image format: {e}"}
        
        # Convert to JPEG if needed and resize if too large
        if image.format not in ['JPEG', 'JPG'] or image.size[0] > 2048 or image.size[1] > 2048:
            # Convert to RGB if needed
            if image.mode in ('RGBA', 'LA', 'P'):
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'P':
                    image = image.convert('RGBA')
                background.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
                image = background
            elif image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Resize if too large
            max_size = (2048, 2048)
            if image.size[0] > max_size[0] or image.size[1] > max_size[1]:
                image.thumbnail(max_size, Image.Resampling.LANCZOS)
                print(f"📏 Resized image to: {image.size}")
            
            # Convert to bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='JPEG', quality=85, optimize=True)
            image_data = img_byte_arr.getvalue()
        else:
            image_data = response.content
        
        # Convert to base64
        image_base64 = base64.b64encode(image_data).decode('utf-8')
        
        return {
            "base64": image_base64,
            "format": "JPEG",
            "size": image.size,
            "data_size": len(image_data),
            "base64_size": len(image_base64)
        }
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error downloading image: {e}")
        return {"error": f"Network error: {e}"}
    except Exception as e:
        print(f"❌ Image processing error: {e}")
        return {"error": f"Image processing error: {e}"}

# ----------------------------
# Feature Flags
# ----------------------------
USE_BEDROCK = os.getenv("USE_BEDROCK_EMBEDDINGS", "false").lower() == "true"
USE_LANGCHAIN = os.getenv("USE_LANGCHAIN_BEDROCK", "false").lower() == "true"

ES_CLOUD_ID = os.getenv("ES_CLOUD_ID")
ES_API_KEY = os.getenv("ES_API_KEY")
ES_INDEX = os.getenv("ES_INDEX", "memories_v1")
VECTOR_DIMS = int(os.getenv("VECTOR_DIMS", "1536"))

# Service selection logic
def get_bedrock_service():
   """Always return LangChain Bedrock Service."""
   if langchain_bedrock_service.enabled:
        print("🔄 Using LangChain Bedrock Service")
        return langchain_bedrock_service
   else:
        print("⚠️ LangChain Bedrock service not available, using fallback")
        return None

# ----------------------------
# DB init
# ----------------------------
Base.metadata.create_all(bind=engine)

# ----------------------------
# Environment configs - UPDATED FOR S3
# ----------------------------
# AWS S3 Configuration (using direct AWS S3)
S3_BUCKET = os.getenv("S3_BUCKET", "memoryos-bucket")
S3_REGION = os.getenv("S3_REGION", os.getenv("AWS_REGION", "us-west-2"))
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_SESSION_TOKEN = os.getenv("AWS_SESSION_TOKEN")  # Optional

# ES_HOST = os.getenv("ES_HOST", "http://elasticsearch:9200")
# ES_INDEX = os.getenv("ES_INDEX", "memories_v1")
# VECTOR_DIMS = int(os.getenv("VECTOR_DIMS", "1536"))

# ----------------------------
# Clients - UPDATED FOR S3
# ----------------------------
# AWS S3 client (using real AWS S3)
s3_client_config = {
    "service_name": "s3",
    "region_name": S3_REGION,
    "aws_access_key_id": AWS_ACCESS_KEY_ID,
    "aws_secret_access_key": AWS_SECRET_ACCESS_KEY,
}

# Add session token if provided
if AWS_SESSION_TOKEN:
    s3_client_config["aws_session_token"] = AWS_SESSION_TOKEN

s3 = boto3.client(**s3_client_config)

# Test S3 connection on startup
try:
    s3.head_bucket(Bucket=S3_BUCKET)
    print(f"✅ Connected to S3 bucket: {S3_BUCKET}")
except Exception as e:
    print(f"❌ S3 connection failed: {e}")
    print(f"🔧 Check bucket exists and credentials are correct")

# Elasticsearch client (no auth, open cluster)
# es = Elasticsearch(
#     ES_HOST,
#     verify_certs=False,
#     ssl_show_warn=False,
#     headers={
#         "Accept": "application/vnd.elasticsearch+json; compatible-with=8",
#         "Content-Type": "application/vnd.elasticsearch+json; compatible-with=8",
#     }
# )
es = Elasticsearch(
    cloud_id=ES_CLOUD_ID,
    api_key=ES_API_KEY,
)

# ----------------------------
# FastAPI app
# ----------------------------
app = FastAPI(title="MemoryOS API (MVP)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Add this startup event handler in main.py
@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    print("🚀 Starting MemoryOS API...")
    
    # Create database tables
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables created/verified")
    
    # Start reminder service
    reminder_service.start()
    print("⏰ Reminder service started")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    print("🛑 Shutting down MemoryOS API...")
    
    # Stop reminder service
    reminder_service.stop()
    print("⏰ Reminder service stopped")
# ----------------------------
# Embedding Functions
# ----------------------------
def generate_random_embedding():
    """Legacy random embedding for fallback."""
    return [random.uniform(0.01, 0.1) for _ in range(VECTOR_DIMS)]

def generate_embedding(text: str) -> List[float]:
    """Smart embedding generation with service selection."""
    service = get_bedrock_service()
    
    if service:
        return service.generate_embedding(text)
    else:
        # Legacy deterministic random for consistency
        seed = sum(ord(c) for c in text) % 100
        random.seed(seed)
        return [random.uniform(0.01, 0.1) for _ in range(VECTOR_DIMS)]

# ----------------------------
# Routes - UPDATED FOR S3
# ----------------------------
@app.get("/health")
def health():
    try:
        es_info = es.info()
        s3_status = "ok"
        try:
            s3.head_bucket(Bucket=S3_BUCKET)
        except Exception as e:
            s3_status = f"error: {str(e)}"
        
        langchain_status = langchain_bedrock_service.get_status() if langchain_bedrock_service.enabled else "disabled"
        
        return {
            "status": "ok", 
            "elasticsearch": {
                "connected": True,
                "cluster": es_info.get("cluster_name")
            },
            "s3": {
                "connected": s3_status == "ok",
                "bucket": S3_BUCKET,
                "region": S3_REGION,
                "status": s3_status
            },
            "services": {
                "bedrock_langchain": {
                    "enabled": langchain_bedrock_service.enabled,
                    "status": langchain_status
                },
                "active_service": "langchain" if langchain_bedrock_service.enabled else "none"
            }
        }
    except Exception as e:
        return {
            "status": "error", 
            "elasticsearch": {"connected": False, "error": str(e)},
            "s3": {"connected": False, "bucket": S3_BUCKET},
            "services": {
                "bedrock_langchain": {"enabled": langchain_bedrock_service.enabled}
            }
        }

@app.post("/upload_url")
def get_upload_url(filename: str = Body(..., embed=True), content_length: Optional[int] = Body(None, embed=True)):
    """Generate presigned URL for direct S3 upload - without ACL (bucket owner enforced)."""
    try:
        # Create unique key with timestamp
        key = f"uploads/{int(time.time())}_{filename}"
        
        # Determine content type
        content_type, _ = mimetypes.guess_type(filename)
        if not content_type:
            content_type = 'application/octet-stream'

        # Generate presigned POST for S3 upload WITHOUT ACL
        conditions = [
            {"Content-Type": content_type},
            {"key": key},
            # REMOVED: {"acl": "public-read"} - bucket doesn't allow ACLs
            ["content-length-range", 1, 50 * 1024 * 1024]  # 1B to 50MB
        ]
        
        # Add content-length condition if provided
        if content_length:
            conditions.append(["content-length-range", content_length, content_length])

        # Remove ACL from Fields - bucket uses BucketOwnerEnforced
        post_data = s3.generate_presigned_post(
            Bucket=S3_BUCKET,
            Key=key,
            Fields={
                "Content-Type": content_type,
                # REMOVED: "acl": "public-read" - not supported by bucket
            },
            Conditions=conditions,
            ExpiresIn=3600  # 1 hour
        )
        
        # Construct the public URL for the uploaded file  
        file_url = f"https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{key}"

        print(f"✅ Generated S3 upload URL for: {filename} -> {key}")
        print(f"🔗 Generated fields: {list(post_data['fields'].keys())}")

        return {
            "upload_url": post_data["url"],
            "fields": post_data["fields"],
            "file_url": file_url,
            "key": key,
            "bucket": S3_BUCKET,
            "content_type": content_type,
            "note": "Files uploaded will inherit bucket's public read policy"
        }
        
    except Exception as e:
        print(f"❌ Failed to generate S3 upload URL: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate upload URL: {str(e)}")

@app.post("/memories", response_model=MemoryOut)
def create_memory(payload: MemoryCreate, background_tasks: BackgroundTasks):
    db: Session = next(get_db())
    
    # Convert MediaItem objects to dicts for storage
    media_data = []
    if payload.media:
        for media_item in payload.media:
            if isinstance(media_item, MediaItem):
                # Convert Pydantic model to dict
                media_data.append(media_item.model_dump())
            elif isinstance(media_item, dict):
                media_data.append(media_item)
            else:
                # Handle string URLs (backward compatibility)
                media_data.append({
                    "type": "unknown",
                    "url": str(media_item),
                    "filename": None
                })
    
    mem = Memory(
        title=payload.title,
        summary=payload.summary,
        captured_at=payload.captured_at or datetime.utcnow(),
        modalities=payload.modalities or [],
        media=media_data,  # Store as list of dicts
        status="pending"
    )
    
    db.add(mem)
    db.commit()
    db.refresh(mem)

    background_tasks.add_task(process_memory, str(mem.id))
    
    # Convert media back to MediaItem objects for response
    response_media = []
    if mem.media:
        for media_dict in mem.media:
            try:
                if isinstance(media_dict, dict):
                    # Create MediaItem from dict, handling missing fields gracefully
                    response_media.append(MediaItem(
                        type=media_dict.get('type', 'unknown'),
                        url=media_dict.get('url', ''),
                        filename=media_dict.get('filename'),
                        content_type=media_dict.get('content_type'),
                        size=media_dict.get('size'),
                        metadata=media_dict.get('metadata')
                    ))
            except Exception as e:
                print(f"Warning: Could not convert media dict to MediaItem: {e}")
                # Skip invalid media items
                continue
    
    return MemoryOut(
        id=str(mem.id), 
        title=mem.title, 
        summary=mem.summary, 
        status=mem.status,
        media=response_media,
        modalities=mem.modalities,
        captured_at=mem.captured_at
    )

# Update the process_memory function to include task extraction
def process_memory(memory_id: str):
    """Enhanced memory processing with task extraction."""
    db = SessionLocal()
    try:
        mem: Memory = db.query(Memory).filter(Memory.id == memory_id).first()
        if not mem:
            print(f"❌ Memory {memory_id} not found")
            return

        print(f"🔄 Processing memory {memory_id}: {mem.title or 'Untitled'}")

        # Get the appropriate service
        service = get_bedrock_service()
        if not service:
            print("⚠️ No Bedrock service available")
            # Fallback processing without AI
            mem.status = "needs_followup"
            db.add(mem)
            db.commit()
            return

        # Set up task extraction service
        task_extraction_service.bedrock_service = service

        # Analyze content type and prepare processing strategy
        has_user_text = bool(mem.title or mem.summary)
        has_images = bool(mem.media and any(
            isinstance(item, dict) and item.get('type') == 'image' 
            for item in mem.media
        ))
        
        print(f"📊 Content analysis: Text={has_user_text}, Images={has_images}")
        print(f"🔧 Using service: {'LangChain' if USE_LANGCHAIN else 'Direct'}")

        # Initialize content variables
        original_title = mem.title or ""
        original_summary = mem.summary or ""
        generated_title = ""
        generated_summary = ""
        ai_descriptions = []
        primary_image_base64 = None
        processed_images = 0
        
        # Process images first (needed for all scenarios with images)
        if has_images:
            print(f"🖼️ Processing {len(mem.media)} media items...")
            
            for i, media_item in enumerate(mem.media):
                if isinstance(media_item, dict) and media_item.get('type') == 'image':
                    image_url = media_item.get('url')
                    if not image_url:
                        continue
                    
                    print(f"🔄 Processing image {i+1}: {image_url}")
                    
                    # Download and prepare image (works with S3 URLs)
                    image_data = download_and_prepare_image(image_url)
                    if "error" in image_data:
                        print(f"⚠️ Failed to process image {i+1}: {image_data['error']}")
                        continue
                    
                    primary_image_base64 = image_data["base64"]
                    
                    # Analyze image using selected service
                    analysis = service.analyze_image(image_data["base64"])
                    if "error" not in analysis and analysis.get("success", True):
                        ai_descriptions.append(analysis["description"])
                        processed_images += 1
                        print(f"✅ Image {i+1} analyzed successfully")
                    else:
                        print(f"⚠️ Image {i+1} analysis failed: {analysis.get('error', 'Unknown error')}")
                    
                    break  # Use first successful image for primary processing

        # SCENARIO HANDLING (same logic, but using selected service)
        embedding_source = "fallback"
        vector = []
        final_title = ""
        final_summary = ""
        enhanced_title = ""
        enhanced_summary = ""
        
        service_type = "langchain" if USE_LANGCHAIN else "direct"
        
        if has_user_text and has_images and primary_image_base64:
            # SCENARIO 2: Text + Summary + Image (Best case)
            print("🎯 Scenario: Text + Image (Multimodal)")
            
            final_title = original_title
            final_summary = original_summary
            
            # Enhance user content with AI insights
            if ai_descriptions:
                enhancement = service.enhance_user_content(
                    original_title, original_summary, ai_descriptions
                )
                enhanced_title = enhancement["enhanced_title"]
                enhanced_summary = enhancement["enhanced_summary"]
            
            # Generate multimodal embedding
            searchable_content = f"{original_title} {original_summary} {' '.join(ai_descriptions)}"
            
            try:
                vector = service.generate_multimodal_embedding(
                    text=searchable_content,
                    image_base64=primary_image_base64
                )
                embedding_source = f"amazon_titan_multimodal_{service_type}"
                print("✅ Generated multimodal embedding")
            except Exception as e:
                print(f"⚠️ Multimodal failed, using text: {e}")
                vector = service.generate_embedding(searchable_content)
                embedding_source = f"amazon_titan_text_enhanced_{service_type}"
        
        elif has_user_text and not has_images:
            # SCENARIO 1: Text + Summary Only
            print("🎯 Scenario: Text Only")
            
            final_title = original_title
            final_summary = original_summary
            enhanced_title = original_title
            enhanced_summary = original_summary
            
            # Generate text embedding
            text_content = f"{original_title} {original_summary}".strip()
            vector = service.generate_embedding(text_content)
            embedding_source = f"amazon_titan_text_{service_type}"
            print("✅ Generated text embedding")
        
        elif not has_user_text and has_images and primary_image_base64:
            # SCENARIO 3: Image Only (Generate title/summary)
            print("🎯 Scenario: Image Only (AI Generation)")
            
            # Generate title and summary from image
            generated_content = service.generate_title_and_summary_from_image(
                primary_image_base64
            )
            
            generated_title = generated_content["title"]
            generated_summary = generated_content["summary"]
            final_title = generated_title
            final_summary = generated_summary
            enhanced_title = generated_title
            enhanced_summary = generated_summary
            
            # Update memory with generated content
            mem.title = generated_title
            mem.summary = generated_summary
            
            # Generate multimodal embedding with AI content
            ai_content = f"{generated_title} {generated_summary}"
            try:
                vector = service.generate_multimodal_embedding(
                    text=ai_content,
                    image_base64=primary_image_base64
                )
                embedding_source = f"amazon_titan_multimodal_generated_{service_type}"
                print("✅ Generated multimodal embedding with AI content")
            except Exception as e:
                print(f"⚠️ Multimodal failed, using text: {e}")
                vector = service.generate_embedding(ai_content)
                embedding_source = f"amazon_titan_text_generated_{service_type}"
        
        else:
            # Fallback case
            print("🎯 Scenario: Fallback")
            final_title = original_title or "Untitled Memory"
            final_summary = original_summary or "No content available"
            enhanced_title = final_title
            enhanced_summary = final_summary
            vector = service.generate_embedding(f"{final_title} {final_summary}")
            embedding_source = f"fallback_{service_type}"

        # Prepare searchable content for hybrid search
        searchable_content = " ".join(filter(None, [
            final_title,
            final_summary,
            enhanced_title if enhanced_title != final_title else "",
            enhanced_summary if enhanced_summary != final_summary else "",
            " ".join(ai_descriptions)
        ]))

        # Store in Elasticsearch with hybrid approach
        doc = {
            "user_id": mem.user_id,
            "title": final_title,
            "summary": final_summary,
            "original_title": original_title,
            "original_summary": original_summary,
            "enhanced_title": enhanced_title,
            "enhanced_summary": enhanced_summary,
            "generated_title": generated_title,
            "generated_summary": generated_summary,
            "searchable_content": searchable_content,
            "captured_at": mem.captured_at.isoformat(),
            "modalities": mem.modalities,
            "media": mem.media,
            "vector": vector,
            "embedding_source": embedding_source,
            "image_descriptions": ai_descriptions,
            "processing_metadata": {
                "scenario": "text_and_image" if has_user_text and has_images else 
                           "text_only" if has_user_text else 
                           "image_only" if has_images else "fallback",
                "service_used": service_type,
                "total_media": len(mem.media or []),
                "processed_images": processed_images,
                "has_ai_generated_content": bool(generated_title or generated_summary),
                "has_enhanced_content": enhanced_title != final_title or enhanced_summary != final_summary,
                "content_sources": {
                    "user_provided": has_user_text,
                    "ai_generated": bool(generated_title or generated_summary),
                    "ai_enhanced": bool(ai_descriptions)
                }
            },
            "safety": {"pii_removed": True}
        }

        es.index(index=ES_INDEX, id=str(mem.id), document=doc, refresh=True)

        mem.status = "ready"
        
        # Store processing metadata in database
        existing_redacted = mem.redacted_json or {}
        processing_metadata = {
            "indexed_at": datetime.utcnow().isoformat(),
            "embedding_source": embedding_source,
            "service_used": service_type,
            "scenario": doc["processing_metadata"]["scenario"],
            "images_processed": processed_images,
            "ai_generated_content": bool(generated_title or generated_summary),
            "content_enhancement": {
                "original_title": original_title,
                "final_title": final_title,
                "generated_title": generated_title,
                "has_ai_descriptions": len(ai_descriptions) > 0
            }
        }
        
        mem.redacted_json = {**existing_redacted, **processing_metadata}
        
        db.add(mem)
        db.commit()
        
        print(f"✅ Enhanced processing complete for memory {memory_id}")
        print(f"📊 Final stats:")
        print(f"   - Service: {service_type}")
        print(f"   - Scenario: {doc['processing_metadata']['scenario']}")
        print(f"   - Embedding: {embedding_source}")
        print(f"   - Images processed: {processed_images}")
        print(f"   - AI generated: {bool(generated_title or generated_summary)}")
        print(f"   - Title: '{final_title}'")
        
        # After successful processing, extract tasks
        if mem.status == "ready":
            print(f"🎯 Extracting tasks from memory {memory_id}")
            
            try:
                # Extract tasks using AI
                extracted_tasks = task_extraction_service.analyze_memory_for_tasks(mem)
                
                if extracted_tasks:
                    # Process and store tasks
                    created_tasks = process_extracted_tasks(memory_id, extracted_tasks, db)
                    
                    print(f"✅ Created {len(created_tasks)} tasks from memory")
                    
                    # Update memory with task metadata
                    existing_redacted = mem.redacted_json or {}
                    existing_redacted["tasks_extracted"] = {
                        "count": len(created_tasks),
                        "extraction_date": datetime.utcnow().isoformat(),
                        "categories": [t.category for t in created_tasks],
                        "task_ids": [t.id for t in created_tasks]
                    }
                    mem.redacted_json = existing_redacted
                    
                    db.add(mem)
                    db.commit()
                else:
                    print("ℹ️ No actionable tasks found in memory")
                    
            except Exception as e:
                print(f"⚠️ Task extraction failed: {e}")
                # Don't fail the entire memory processing if task extraction fails
        
        print(f"✅ Memory processing complete for {memory_id}")
        
    except Exception as e:
        try:
            mem.status = "needs_followup"
            db.add(mem)
            db.commit()
        except:
            pass
        print(f"❌ Processing error for memory {memory_id}: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

def process_extracted_tasks(memory_id: str, extracted_tasks: List[Dict], db: Session) -> List[Task]:
    """Process and store extracted tasks in database."""
    created_tasks = []
    
    for task_data in extracted_tasks:
        try:
            # Skip low-confidence tasks
            if task_data.get("confidence", 0) < 0.7:
                print(f"⏭️ Skipping low-confidence task: {task_data.get('title')}")
                continue
            
            # Parse due date
            due_date = None
            if task_data.get("due_date"):
                try:
                    if isinstance(task_data["due_date"], str):
                        due_date = datetime.fromisoformat(task_data["due_date"])
                    elif isinstance(task_data["due_date"], datetime):
                        due_date = task_data["due_date"]
                except:
                    print(f"⚠️ Could not parse due date: {task_data.get('due_date')}")
            
            # Calculate reminder date (1 day before due date, or 7 days from now)
            reminder_date = None
            if due_date:
                reminder_date = due_date - timedelta(days=1)
                # If reminder would be in the past, set it for tomorrow
                if reminder_date < datetime.utcnow():
                    reminder_date = datetime.utcnow() + timedelta(days=1)
            else:
                # Default reminder: 7 days from now
                reminder_date = datetime.utcnow() + timedelta(days=7)
            
            # Create task
            task = Task(
                memory_id=memory_id,
                title=task_data["title"][:200],  # Truncate if too long
                description=task_data.get("description", "")[:500],
                category=task_data["category"],
                due_date=due_date,
                reminder_date=reminder_date,
                priority=task_data.get("priority", "medium"),
                ai_confidence=task_data.get("confidence", 0.0),
                extraction_metadata={
                    "extraction_method": "ai" if task_extraction_service.bedrock_service else "rules",
                    "extracted_at": datetime.utcnow().isoformat(),
                    "reasoning": task_data.get("reasoning", ""),
                    "original_memory_title": db.query(Memory).filter(Memory.id == memory_id).first().title
                },
                user_approved=False,  # Require user approval for AI-generated tasks
                user_modified=False
            )
            
            db.add(task)
            created_tasks.append(task)
            
            print(f"✅ Created task: {task.title} (confidence: {task.ai_confidence:.2f})")
            
        except Exception as e:
            print(f"❌ Failed to create task from {task_data}: {e}")
            continue
    
    try:
        db.commit()
        print(f"💾 Saved {len(created_tasks)} tasks to database")
    except Exception as e:
        print(f"❌ Failed to save tasks: {e}")
        db.rollback()
        return []
    
    return created_tasks

@app.post("/search")
def search_memories(request: SearchRequest):
    """Enhanced hybrid search with service selection."""
    try:
        query = request.query.strip()
        if not query:
            return {"results": [], "total": 0, "query": query}

        print(f"🔍 Enhanced search query: '{query}'")

        # Generate query embedding using selected service
        service = get_bedrock_service()
        query_vector = []
        
        if service:
            try:
                query_vector = service.generate_embedding(query)
                service_type = "langchain" if USE_LANGCHAIN else "direct"
                print(f"✅ Generated query embedding ({len(query_vector)}D) using {service_type}")
            except Exception as e:
                print(f"⚠️ Query embedding failed: {e}")

        # Enhanced hybrid search query
        search_body = {
            "size": request.k,
            "query": {
                "bool": {
                    "should": [
                        # Vector similarity search
                        {
                            "knn": {
                                "field": "vector",
                                "query_vector": query_vector,
                                "k": request.k * 2,
                                "boost": 2.0
                            }
                        } if query_vector else {},
                        
                        # Multi-field text search with different strategies
                        {
                            "multi_match": {
                                "query": query,
                                "fields": [
                                    "title^4",
                                    "enhanced_title^3",
                                    "summary^3",
                                    "enhanced_summary^2",
                                    "searchable_content^2",
                                    "image_descriptions^1.5",
                                    "generated_title^2",
                                    "generated_summary^1.5"
                                ],
                                "type": "best_fields",
                                "boost": 3.0
                            }
                        },
                        
                        # Fuzzy matching for typos
                        {
                            "multi_match": {
                                "query": query,
                                "fields": ["title", "summary", "searchable_content"],
                                "fuzziness": "AUTO",
                                "boost": 1.0
                            }
                        }
                    ],
                    "minimum_should_match": 1
                }
            },
            "_source": {
                "includes": [
                    "title", "summary", "captured_at", "modalities", "media",
                    "embedding_source", "image_descriptions", "processing_metadata",
                    "enhanced_title", "enhanced_summary", "original_title", "original_summary"
                ]
            }
        }

        # Remove empty KNN query if no vector
        search_body["query"]["bool"]["should"] = [
            q for q in search_body["query"]["bool"]["should"] if q
        ]

        response = es.search(index=ES_INDEX, body=search_body)
        
        results = []
        for hit in response['hits']['hits']:
            source = hit['_source']
            
            # Determine which content to show in results
            display_title = source.get('title') or source.get('generated_title', 'Untitled')
            display_summary = source.get('summary') or source.get('generated_summary', '')
            
            result = {
                "id": hit['_id'],
                "title": display_title,
                "summary": display_summary,
                "score": hit['_score'],
                "captured_at": source.get('captured_at'),
                "modalities": source.get('modalities', []),
                "media": source.get('media', []),
                "embedding_source": source.get('embedding_source'),
                "image_descriptions": source.get('image_descriptions', []),
                "content_metadata": {
                    "scenario": source.get('processing_metadata', {}).get('scenario'),
                    "service_used": source.get('processing_metadata', {}).get('service_used'),
                    "is_ai_generated": bool(source.get('generated_title') or source.get('generated_summary')),
                    "is_enhanced": source.get('enhanced_title') != source.get('title') or 
                                  source.get('enhanced_summary') != source.get('summary'),
                    "has_images": len(source.get('media', [])) > 0
                }
            }
            results.append(result)

        service_type = "langchain" if USE_LANGCHAIN else "direct" if service else "none"
        print(f"✅ Enhanced search complete: {len(results)} results (using {service_type})")
        
        return {
            "results": results,
            "total": response['hits']['total']['value'],
            "query": query,
            "search_metadata": {
                "vector_search_enabled": bool(query_vector),
                "service_used": service_type,
                "hybrid_fields_searched": [
                    "title", "summary", "enhanced_content", "ai_descriptions", "generated_content"
                ]
            }
        }

    except Exception as e:
        print(f"❌ Enhanced search error: {e}")
        return {"results": [], "total": 0, "query": query, "error": str(e)}

@app.get("/debug/services")
def debug_services():
    """Debug LangChain Bedrock service only."""
    return {
        "services": {
            "langchain_bedrock": langchain_bedrock_service.get_status()
        },
        "active_service": "langchain" if langchain_bedrock_service.enabled else "none"
    }


# ...existing code...

@app.post("/sync_zoom_meetings")
def sync_zoom_meetings(background_tasks: BackgroundTasks):
    """Sync FUTURE Zoom meetings with simple and reliable deduplication."""
    try:
        zoom_client_id = os.getenv("ZOOM_CLIENT_ID")
        zoom_client_secret = os.getenv("ZOOM_CLIENT_SECRET") 
        zoom_account_id = os.getenv("ZOOM_ACCOUNT_ID")
        
        if not all([zoom_client_id, zoom_client_secret, zoom_account_id]):
            raise HTTPException(status_code=400, detail="Zoom credentials not configured")
        
        print("🔄 Starting Zoom sync - FUTURE MEETINGS ONLY")
        
        # Fetch FUTURE meetings from Zoom API
        meetings = get_zoom_meetings_with_details(zoom_client_id, zoom_client_secret, zoom_account_id)
        print(f"📥 Fetched {len(meetings)} FUTURE meetings from Zoom API")
        
        if not meetings:
            return {
                "status": "success",
                "message": "No future meetings found in Zoom",
                "total_fetched": 0,
                "new_meetings": 0,
                "updated_meetings": 0,
                "skipped_duplicates": 0
            }
        
        db: Session = next(get_db())
        synced_meetings = []
        skipped_meetings = []
        updated_meetings = []
        
        # Get ALL existing memories that might be Zoom meetings
        # We'll check them in Python to avoid SQL complexity
        all_meeting_memories = db.query(Memory).filter(
            Memory.title.like("%Meeting:%") | Memory.title.like("%Zoom%")
        ).all()
        
        print(f"🔍 Found {len(all_meeting_memories)} existing meeting memories in DB")
        
        # Create a map of existing zoom_meeting_id -> Memory
        existing_zoom_meetings = {}
        for mem in all_meeting_memories:
            try:
                if mem.redacted_json and isinstance(mem.redacted_json, dict):
                    zoom_id = mem.redacted_json.get('zoom_meeting_id')
                    if zoom_id:
                        existing_zoom_meetings[str(zoom_id)] = mem
                        print(f"📋 Found existing meeting: {zoom_id} -> {mem.title}")
            except Exception as e:
                print(f"⚠️ Error processing memory {mem.id}: {e}")
                continue
        
        print(f"🗂️ Mapped {len(existing_zoom_meetings)} existing Zoom meetings")
        
        # Process each FUTURE meeting from Zoom API
        for meeting_data in meetings:
            zoom_meeting_id = str(meeting_data['id'])
            meeting_title = meeting_data['title']
            meeting_start = meeting_data.get('start_time', 'Unknown time')
            
            print(f"\n🔄 Processing FUTURE meeting: {zoom_meeting_id} - {meeting_title} ({meeting_start})")
            
            # Check if this meeting already exists
            existing_memory = existing_zoom_meetings.get(zoom_meeting_id)
            
            if existing_memory:
                print(f"✅ Found existing memory: {existing_memory.id}")
                
                # Check if we need to update the summary
                new_summary = meeting_data['formatted_summary']
                
                if existing_memory.summary != new_summary:
                    print(f"🔄 Updating existing memory with new summary")
                    
                    existing_memory.summary = new_summary
                    existing_memory.status = "pending"
                    
                    # Update redacted_json while preserving existing data
                    existing_redacted = existing_memory.redacted_json or {}
                    existing_redacted.update({
                        "zoom_meeting_id": zoom_meeting_id,
                        "updated_at": datetime.utcnow().isoformat(),
                        "sync_source": "zoom_api_future_only",
                        "is_future_meeting": True
                    })
                    existing_memory.redacted_json = existing_redacted
                    
                    db.add(existing_memory)
                    db.commit()
                    
                    # Re-process the updated memory
                    background_tasks.add_task(process_memory, str(existing_memory.id))
                    
                    updated_meetings.append({
                        "memory_id": str(existing_memory.id),
                        "zoom_meeting_id": zoom_meeting_id,
                        "title": meeting_title,
                        "start_time": meeting_start,
                        "action": "updated",
                        "attendees_count": len(meeting_data.get('attendees', []))
                    })
                else:
                    print(f"⏭️ No changes needed, skipping")
                    
                    skipped_meetings.append({
                        "memory_id": str(existing_memory.id),
                        "zoom_meeting_id": zoom_meeting_id,
                        "title": meeting_title,
                        "start_time": meeting_start,
                        "action": "skipped_duplicate",
                        "attendees_count": len(meeting_data.get('attendees', []))
                    })
            else:
                print(f"🆕 Creating new memory for FUTURE meeting")
                
                # Create new memory for future meeting
                memory = Memory(
                    title=f"Meeting: {meeting_title}",
                    summary=meeting_data['formatted_summary'],
                    captured_at=datetime.fromisoformat(meeting_data['start_time'].replace('Z', '+00:00')) if meeting_data.get('start_time') else datetime.utcnow(),
                    modalities=["meeting", "zoom", "scheduled"],
                    media=[],
                    status="pending",
                    redacted_json={
                        "zoom_meeting_id": zoom_meeting_id,
                        "created_at": datetime.utcnow().isoformat(),
                        "sync_source": "zoom_api_future_only",
                        "is_future_meeting": True,
                        "meeting_url": meeting_data.get('meeting_link', ''),
                        "scheduled_time": meeting_data.get('start_time', ''),
                        "duration_minutes": meeting_data.get('duration', 0)
                    }
                )
                
                db.add(memory)
                db.commit()
                db.refresh(memory)
                
                print(f"✅ Created new memory: {memory.id}")
                
                # Process the new memory (will extract tasks!)
                background_tasks.add_task(process_memory, str(memory.id))
                
                synced_meetings.append({
                    "memory_id": str(memory.id),
                    "zoom_meeting_id": zoom_meeting_id,
                    "title": meeting_title,
                    "start_time": meeting_start,
                    "action": "created",
                    "attendees_count": len(meeting_data.get('attendees', []))
                })
        
        db.close()
        
        result = {
            "status": "success",
            "message": f"Synced {len(synced_meetings)} future meetings, updated {len(updated_meetings)}, skipped {len(skipped_meetings)} duplicates",
            "total_fetched": len(meetings),
            "new_meetings": len(synced_meetings),
            "updated_meetings": len(updated_meetings),
            "skipped_duplicates": len(skipped_meetings),
            "meeting_type": "future_scheduled_only",
            "details": {
                "created": synced_meetings,
                "updated": updated_meetings,
                "skipped": skipped_meetings
            }
        }
        
        print(f"📊 FUTURE meetings sync complete: {result}")
        return result
        
    except Exception as e:
        print(f"❌ Future meetings sync failed: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")

# ...existing code...
# Make sure these endpoints are AFTER all other routes in main.py

# ✅ TASK MANAGEMENT ENDPOINTS - CLEANED VERSION

@app.get("/tasks/summary", response_model=TaskSummary)
def get_task_summary(user_id: str = "default_user"):
    """Get task summary statistics for dashboard."""
    db: Session = next(get_db())
    
    try:
        print(f"📊 Generating task summary for user: {user_id}")
        
        # Get all user tasks
        tasks = db.query(Task).filter(Task.user_id == user_id).all()
        
        # Calculate statistics
        total_tasks = len(tasks)
        pending_approval = len([t for t in tasks if not t.user_approved and t.status == "pending"])
        active_tasks = len([t for t in tasks if t.user_approved and t.status == "pending"])
        completed_tasks = len([t for t in tasks if t.status == "completed"])
        
        # Calculate overdue tasks (only for approved tasks)
        now = datetime.utcnow()
        overdue_tasks = len([
            t for t in tasks 
            if t.user_approved and t.status == "pending" and t.due_date and t.due_date < now
        ])
        
        # Tasks due today (only approved tasks)
        today_end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
        due_today = len([
            t for t in tasks 
            if t.user_approved and t.status == "pending" and t.due_date and now <= t.due_date <= today_end
        ])
        
        # Tasks due this week (only approved tasks)
        week_end = now + timedelta(days=7)
        due_this_week = len([
            t for t in tasks 
            if t.user_approved and t.status == "pending" and t.due_date and now <= t.due_date <= week_end
        ])
        
        # Group by categories (only approved active tasks)
        categories = {}
        for task in tasks:
            if task.user_approved and task.status == "pending":
                categories[task.category] = categories.get(task.category, 0) + 1
        
        # Group by priorities (only approved active tasks)
        priorities = {}
        for task in tasks:
            if task.user_approved and task.status == "pending":
                priorities[task.priority] = priorities.get(task.priority, 0) + 1
        
        summary = TaskSummary(
            total_tasks=total_tasks,
            pending_tasks=active_tasks,
            completed_tasks=completed_tasks,
            overdue_tasks=overdue_tasks,
            due_today=due_today,
            due_this_week=due_this_week,
            categories=categories,
            priorities=priorities,
            pending_approval=pending_approval
        )
        
        print(f"📊 Summary: {pending_approval} pending approval, {active_tasks} active")
        return summary
        
    except Exception as e:
        print(f"❌ Failed to generate task summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.get("/tasks/pending-approval", response_model=List[TaskOut])
def get_tasks_pending_approval(user_id: str = "default_user"):
    """Get tasks awaiting user approval."""
    db: Session = next(get_db())
    
    try:
        tasks = db.query(Task).filter(
            Task.user_id == user_id,
            Task.user_approved == False,
            Task.status == "pending"
        ).order_by(Task.created_at.desc()).all()
        
        print(f"🔍 Found {len(tasks)} tasks pending approval")
        return tasks
        
    except Exception as e:
        print(f"❌ Failed to get pending approval tasks: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.get("/tasks/active", response_model=List[TaskOut])
def get_active_tasks(user_id: str = "default_user"):
    """Get approved and active tasks."""
    db: Session = next(get_db())
    
    try:
        tasks = db.query(Task).filter(
            Task.user_id == user_id,
            Task.user_approved == True,
            Task.status == "pending"
        ).order_by(
            Task.due_date.asc().nulls_last(),
            Task.created_at.desc()
        ).all()
        
        print(f"📋 Found {len(tasks)} active tasks")
        return tasks
        
    except Exception as e:
        print(f"❌ Failed to get active tasks: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.post("/tasks/{task_id}/approve")
def approve_task(task_id: str):
    """Approve an AI-generated task."""
    db: Session = next(get_db())
    
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task.user_approved = True
        task.updated_at = datetime.utcnow()
        
        db.add(task)
        db.commit()
        
        print(f"👍 Approved task: {task.title}")
        return {"message": f"Task '{task.title}' approved"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Failed to approve task {task_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.post("/tasks/{task_id}/disapprove")
def disapprove_task(task_id: str):
    """Disapprove and delete an AI-generated task."""
    db: Session = next(get_db())
    
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task_title = task.title
        
        # Delete the disapproved task
        db.delete(task)
        db.commit()
        
        print(f"👎 Disapproved and removed task: {task_title}")
        return {"message": f"Task '{task_title}' disapproved and removed"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Failed to disapprove task {task_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.post("/tasks/{task_id}/complete")
def complete_task(task_id: str):
    """Complete and remove a task."""
    db: Session = next(get_db())
    
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task_title = task.title
        
        # Delete completed task (as per your flow)
        db.delete(task)
        db.commit()
        
        print(f"✅ Completed and removed task: {task_title}")
        return {"message": f"Task '{task_title}' completed and removed"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Failed to complete task {task_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.put("/tasks/{task_id}", response_model=TaskOut)
def update_task(task_id: str, task_update: TaskUpdate):
    """Update an existing task."""
    db: Session = next(get_db())
    
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Update fields if provided
        update_data = task_update.model_dump(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(task, field):
                setattr(task, field, value)
        
        # Mark as user modified if any content fields were changed
        content_fields = ["title", "description", "due_date", "priority", "status"]
        if any(field in update_data for field in content_fields):
            task.user_modified = True
        
        task.updated_at = datetime.utcnow()
        
        db.add(task)
        db.commit()
        db.refresh(task)
        
        print(f"✅ Updated task: {task.title}")
        return task
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Failed to update task {task_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@app.get("/notifications/{user_id}")
def get_notifications(user_id: str):
    """Get recent notifications for user (Simple Polling)."""
    db: Session = next(get_db())
    
    try:
        # Count pending approval tasks
        pending_count = db.query(Task).filter(
            Task.user_id == user_id,
            Task.user_approved == False,
            Task.status == "pending"
        ).count()
        
        # Count overdue tasks (only approved tasks)
        overdue_count = db.query(Task).filter(
            Task.user_id == user_id,
            Task.user_approved == True,
            Task.status == "pending",
            Task.due_date < datetime.utcnow()
        ).count()
        
        # Count due today (only approved tasks)
        today_end = datetime.utcnow().replace(hour=23, minute=59, second=59)
        due_today_count = db.query(Task).filter(
            Task.user_id == user_id,
            Task.user_approved == True,
            Task.status == "pending",
            Task.due_date <= today_end,
            Task.due_date >= datetime.utcnow()
        ).count()
        
        notifications = []
        
        if pending_count > 0:
            notifications.append({
                "type": "pending_approval",
                "title": "Tasks Need Approval",
                "message": f"You have {pending_count} new task{'s' if pending_count != 1 else ''} waiting for approval",
                "count": pending_count,
                "priority": "high",
                "action_url": "/tasks/pending-approval"
            })
        
        if overdue_count > 0:
            notifications.append({
                "type": "overdue_tasks",
                "title": "Overdue Tasks",
                "message": f"You have {overdue_count} overdue task{'s' if overdue_count != 1 else ''}",
                "count": overdue_count,
                "priority": "urgent",
                "action_url": "/tasks/active"
            })
        
        if due_today_count > 0:
            notifications.append({
                "type": "due_today",
                "title": "Tasks Due Today",
                "message": f"You have {due_today_count} task{'s' if due_today_count != 1 else ''} due today",
                "count": due_today_count,
                "priority": "medium",
                "action_url": "/tasks/active"
            })
        
        return {
            "notifications": notifications,
            "total": len(notifications),
            "user_id": user_id,
            "timestamp": datetime.utcnow().isoformat(),
            "summary": {
                "pending_approval": pending_count,
                "overdue": overdue_count,
                "due_today": due_today_count
            }
        }
        
    except Exception as e:
        print(f"❌ Failed to get notifications: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.get("/all/memories", response_model=List[MemoryOut])
def get_all_memories(db: Session = Depends(get_db)):
    """Fetch all memories stored in Postgres."""
    try:
        memories = db.query(Memory).all()

        result = []
        for mem in memories:
            media_items = []
            if mem.media:
                for media_dict in mem.media:
                    try:
                        if isinstance(media_dict, dict):
                            media_items.append(MediaItem(
                                type=media_dict.get("type", "unknown"),
                                url=media_dict.get("url", ""),
                                filename=media_dict.get("filename"),
                                content_type=media_dict.get("content_type"),
                                size=media_dict.get("size"),
                                metadata=media_dict.get("metadata")
                            ))
                    except Exception as e:
                        print(f"⚠️ Skipping bad media: {e}")
                        continue

            result.append(MemoryOut(
                id=str(mem.id),
                title=mem.title,
                summary=mem.summary,
                status=mem.status,
                media=media_items,
                modalities=mem.modalities,
                captured_at=mem.captured_at
            ))
        return result
    except Exception as e:
        print(f"❌ Failed to fetch memories: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch memories")