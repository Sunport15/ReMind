import requests
import base64
import io
from PIL import Image
from typing import Dict, Any, Optional

def download_and_prepare_image(image_url: str) -> Dict[str, Any]:
    """Download image from URL and prepare it for Bedrock analysis."""
    try:
        print(f"📥 Downloading image from: {image_url}")
        
        # Download image
        response = requests.get(image_url, timeout=30)
        if response.status_code != 200:
            return {"error": f"Failed to download image: HTTP {response.status_code}"}
        
        # Validate image
        try:
            image = Image.open(io.BytesIO(response.content))
            print(f"📸 Image info: {image.format} {image.size} {image.mode}")
        except Exception as e:
            return {"error": f"Invalid image format: {e}"}
        
        # Convert to JPEG if needed and resize if too large
        if image.format not in ['JPEG', 'JPG'] or image.size[0] > 2048 or image.size[1] > 2048:
            # Convert to RGB if needed
            if image.mode in ('RGBA', 'LA', 'P'):
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'P':
                    image = image.convert('RGBA')
                background.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
                image = background
            elif image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Resize if too large
            max_size = (2048, 2048)
            if image.size[0] > max_size[0] or image.size[1] > max_size[1]:
                image.thumbnail(max_size, Image.Resampling.LANCZOS)
                print(f"📏 Resized image to: {image.size}")
            
            # Convert to bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='JPEG', quality=85, optimize=True)
            image_data = img_byte_arr.getvalue()
        else:
            image_data = response.content
        
        # Convert to base64
        image_base64 = base64.b64encode(image_data).decode('utf-8')
        
        return {
            "base64": image_base64,
            "format": "JPEG",
            "size": image.size,
            "data_size": len(image_data),
            "base64_size": len(image_base64)
        }
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error downloading image: {e}")
        return {"error": f"Network error: {e}"}
    except Exception as e:
        print(f"❌ Image processing error: {e}")
        return {"error": f"Image processing error: {e}"}