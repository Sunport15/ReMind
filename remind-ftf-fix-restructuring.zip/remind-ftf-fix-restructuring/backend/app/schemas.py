from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional, Dict, Any

class MediaItem(BaseModel):
    """Schema for media items (images, videos, etc.)"""
    type: str  # "image", "video", "audio", etc.
    url: str   # Full URL to the media file
    filename: Optional[str] = None
    content_type: Optional[str] = None
    size: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None

class MemoryCreate(BaseModel):
    title: Optional[str] = None
    summary: Optional[str] = None
    captured_at: Optional[datetime] = None
    modalities: Optional[List[str]] = []
    media: Optional[List[MediaItem]] = []  # ✅ Fixed: Now accepts MediaItem objects

class MemoryOut(BaseModel):
    id: str
    title: Optional[str]
    summary: Optional[str]
    status: str
    media: Optional[List[MediaItem]] = []  # ✅ Include media in output
    modalities: Optional[List[str]] = []
    captured_at: Optional[datetime] = None

class SearchRequest(BaseModel):
    query: str
    k: Optional[int] = 5
    media_type: Optional[str] = None
    user_id: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None

class SearchResult(BaseModel):
    id: str
    title: str
    summary: str
    score: float
    captured_at: str  # ISO format datetime string
    modalities: List[str] = []
    media: List[MediaItem] = []
    embedding_source: str
    image_descriptions: List[str] = []
    content_metadata: Optional[Dict[str, Any]] = None

class SearchResponse(BaseModel):
    results: List[SearchResult]
    total: int
    query: str
    search_metadata: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

# ✅ NEW: Task Schemas
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category: str
    due_date: Optional[datetime] = None
    reminder_date: Optional[datetime] = None
    priority: str = "medium"

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    due_date: Optional[datetime] = None
    reminder_date: Optional[datetime] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    user_approved: Optional[bool] = None

class TaskOut(BaseModel):
    id: str
    memory_id: str
    title: str
    description: Optional[str]
    category: str
    due_date: Optional[datetime]
    reminder_date: Optional[datetime]
    status: str
    priority: str
    ai_confidence: Optional[float]
    extraction_metadata: Optional[Dict[str, Any]]
    user_approved: bool
    user_modified: bool
    created_at: datetime
    updated_at: datetime

class TaskSummary(BaseModel):
    total_tasks: int
    pending_tasks: int  # Now means approved pending tasks
    completed_tasks: int
    overdue_tasks: int
    due_today: int
    due_this_week: int
    categories: Dict[str, int]
    priorities: Dict[str, int]
    pending_approval: int  # New field for tasks awaiting approval
