import uuid
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, Boolean, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from .database import Base
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSON

class Memory(Base):
    __tablename__ = "memories"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, default="default_user")
    title = Column(String, nullable=True)
    summary = Column(Text, nullable=True)
    captured_at = Column(DateTime, default=datetime.utcnow)
    modalities = Column(JSON, default=list)  # Store as JSON array
    media = Column(JSON, default=list)       # ✅ Store as JSON array of objects
    redacted_json = Column(JSON, nullable=True)
    pii_risk = Column(String, default="low")
    status = Column(String, default="pending")

# ✅ NEW: Task Model
class Task(Base):
    __tablename__ = "tasks"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, default="default_user")
    memory_id = Column(String, ForeignKey("memories.id"), nullable=False)
    
    # Task details
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String, nullable=False)  # "healthcare", "work", "personal", etc.
    
    # Timing
    due_date = Column(DateTime, nullable=True)
    reminder_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Status
    status = Column(String, default="pending")  # "pending", "completed", "cancelled"
    priority = Column(String, default="medium")  # "low", "medium", "high", "urgent"
    
    # AI metadata
    ai_confidence = Column(Float, default=0.0)  # 0.0 to 1.0
    extraction_metadata = Column(JSON, nullable=True)
    
    # User interaction
    user_approved = Column(Boolean, default=False)
    user_modified = Column(Boolean, default=False)
    
    def __repr__(self):
        return f"<Task(id={self.id}, title='{self.title}', status='{self.status}')>"
