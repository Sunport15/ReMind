import schedule
import time
import threading
from datetime import datetime, timedelta
from typing import List
from ..database import SessionLocal
from ..models import Task

class ReminderService:
    """Background service for checking and sending task reminders."""
    
    def __init__(self):
        self.running = False
        self.thread = None
    
    def start(self):
        """Start the reminder service."""
        if not self.running:
            self.running = True
            
            # Schedule reminder checks
            schedule.every(1).hours.do(self.check_reminders)
            schedule.every().day.at("09:00").do(self.send_daily_summary)
            
            # Start background thread
            self.thread = threading.Thread(target=self._run_scheduler)
            self.thread.daemon = True
            self.thread.start()
            
            print("⏰ Reminder service started")
    
    def stop(self):
        """Stop the reminder service."""
        self.running = False
        schedule.clear()
        print("⏰ Reminder service stopped")
    
    def _run_scheduler(self):
        """Run the scheduler in background thread."""
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
            except Exception as e:
                print(f"❌ Reminder service error: {e}")
                time.sleep(300)  # Wait 5 minutes before retrying
    
    def check_reminders(self):
        """Check for tasks that need reminders."""
        db = SessionLocal()
        
        try:
            # Find tasks due for reminders
            now = datetime.utcnow()
            
            # Tasks with reminders due now
            reminder_tasks = db.query(Task).filter(
                Task.status == "pending",
                Task.reminder_date <= now,
                Task.reminder_date >= now - timedelta(hours=1)  # Only recent reminders
            ).all()
            
            if reminder_tasks:
                print(f"⏰ Processing {len(reminder_tasks)} reminders")
                
                for task in reminder_tasks:
                    self.send_reminder(task)
                    
                    # Update reminder date to avoid duplicate reminders
                    if task.due_date:
                        # Set next reminder for day before due date
                        task.reminder_date = task.due_date - timedelta(days=1)
                    else:
                        # Set next reminder for 7 days later
                        task.reminder_date = now + timedelta(days=7)
                    
                    db.add(task)
                
                db.commit()
                print(f"✅ Processed {len(reminder_tasks)} reminders")
            
        except Exception as e:
            print(f"❌ Reminder check failed: {e}")
            db.rollback()
        finally:
            db.close()
    
    def send_reminder(self, task: Task):
        """Send a reminder for a specific task."""
        try:
            # For now, just log the reminder
            # In production, you'd send email, push notification, etc.
            
            urgency = ""
            if task.due_date:
                days_until_due = (task.due_date - datetime.utcnow()).days
                if days_until_due <= 0:
                    urgency = "🚨 OVERDUE"
                elif days_until_due == 1:
                    urgency = "⚠️ DUE TOMORROW"
                elif days_until_due <= 3:
                    urgency = "📅 DUE SOON"
            
            reminder_message = f"""
            {urgency} Task Reminder:
            
            📋 {task.title}
            📝 {task.description}
            🏷️ Category: {task.category.title()}
            ⭐ Priority: {task.priority.title()}
            📅 Due: {task.due_date.strftime('%Y-%m-%d %H:%M') if task.due_date else 'No due date'}
            """
            
            print(f"📧 REMINDER: {task.title} ({task.category}) - Priority: {task.priority}")
            
            # Here you would integrate with:
            # - Email service (SendGrid, AWS SES)
            # - Push notifications (FCM, APNS)
            # - SMS service (Twilio)
            # - Slack/Discord webhooks
            # - etc.
            
        except Exception as e:
            print(f"❌ Failed to send reminder for task {task.id}: {e}")
    
    def send_daily_summary(self):
        """Send daily task summary to users."""
        db = SessionLocal()
        
        try:
            # Get users with pending tasks
            users_with_tasks = db.query(Task.user_id).filter(
                Task.status == "pending"
            ).distinct().all()
            
            for (user_id,) in users_with_tasks:
                self.send_user_daily_summary(user_id, db)
            
        except Exception as e:
            print(f"❌ Daily summary failed: {e}")
        finally:
            db.close()
    
    def send_user_daily_summary(self, user_id: str, db):
        """Send daily summary for a specific user."""
        try:
            now = datetime.utcnow()
            today_end = now.replace(hour=23, minute=59, second=59)
            
            # Get tasks due today
            due_today = db.query(Task).filter(
                Task.user_id == user_id,
                Task.status == "pending",
                Task.due_date >= now,
                Task.due_date <= today_end
            ).all()
            
            # Get overdue tasks
            overdue = db.query(Task).filter(
                Task.user_id == user_id,
                Task.status == "pending",
                Task.due_date < now
            ).all()
            
            if due_today or overdue:
                summary = f"""
                🌅 Daily Task Summary for {now.strftime('%Y-%m-%d')}
                
                {"🚨 OVERDUE TASKS:" if overdue else ""}
                {chr(10).join([f"- {task.title} (Due: {task.due_date.strftime('%Y-%m-%d')})" for task in overdue])}
                
                {"📅 DUE TODAY:" if due_today else ""}
                {chr(10).join([f"- {task.title} (Priority: {task.priority})" for task in due_today])}
                
                Total pending tasks: {len(overdue) + len(due_today)}
                """
                
                print(f"📊 Daily summary for {user_id}: {len(due_today)} due today, {len(overdue)} overdue")
                
                # Send summary (implement your preferred method)
                # self.send_notification(user_id, "Daily Task Summary", summary)
            
        except Exception as e:
            print(f"❌ Failed to send daily summary for {user_id}: {e}")

# Global reminder service instance
reminder_service = ReminderService()