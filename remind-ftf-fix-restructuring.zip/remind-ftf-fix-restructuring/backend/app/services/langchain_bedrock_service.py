"""
LangChain-based Bedrock service with hybrid approach
Uses LangChain where possible, direct boto3 for multimodal embeddings
"""
import os
import json
import boto3
import random
import re
import base64
from typing import List, Optional, Dict, Any
from botocore.exceptions import ClientError, NoCredentialsError

# LangChain imports
try:
    from langchain_aws import ChatBedrock, BedrockEmbeddings
    from langchain_core.messages import HumanMessage
    from langchain_core.prompts import ChatPromptTemplate
    LANGCHAIN_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ LangChain not available: {e}")
    print("💡 Install with: pip install langchain-aws langchain-community langchain-core")
    LANGCHAIN_AVAILABLE = False
    # Mock classes to prevent import errors
    class ChatBedrock: pass
    class BedrockEmbeddings: pass
    class HumanMessage: pass
    class ChatPromptTemplate: pass

class LangChainBedrockService:
    """LangChain-based implementation with hybrid approach for multimodal embeddings."""
    
    def __init__(self):
        self.enabled = False
        self.langchain_available = LANGCHAIN_AVAILABLE
        self.bedrock_runtime = None
        
        # Same model configuration as original service
        self.region = os.getenv("AWS_REGION", "ap-south-1")
        self.text_embedding_model = os.getenv("BEDROCK_TEXT_MODEL", "amazon.titan-embed-text-v2:0")
        self.multimodal_embedding_model = os.getenv("BEDROCK_IMAGE_MODEL", "amazon.titan-multimodal-embed-g1:0")
        self.vision_model = os.getenv("BEDROCK_VISION_MODEL", "amazon.nova-pro-v1:0")
        
        if self.langchain_available:
            self._initialize_client()
        else:
            print("❌ LangChain not available - service disabled")
    
    def _initialize_client(self):
        """Initialize LangChain models and direct boto3 client."""
        try:
            # Initialize direct boto3 client for multimodal embeddings
            self.bedrock_runtime = boto3.client(
                'bedrock-runtime',
                region_name=self.region
            )
            
            # Initialize LangChain models
            self.vision_model_lc = ChatBedrock(
                model_id=self.vision_model,
                region_name=self.region,
                model_kwargs={
                    "max_tokens": 1000,
                    "temperature": 0.1,
                    "top_p": 0.9
                }
            )
            
            self.text_embeddings_lc = BedrockEmbeddings(
                model_id=self.text_embedding_model,
                region_name=self.region
            )
            
            # Test connection
            self._test_connection()
            self.enabled = True
            
            print(f"✅ LangChain Bedrock service initialized successfully")
            print(f"📝 Text Model (LangChain): {self.text_embedding_model}")
            print(f"🖼️ Multimodal Model (Direct): {self.multimodal_embedding_model}")
            print(f"👁️ Vision Model (LangChain): {self.vision_model}")
            
        except Exception as e:
            print(f"⚠️ LangChain Bedrock initialization failed: {e}")
            self.enabled = False
    
    def _test_connection(self):
        """Test LangChain connection."""
        try:
            # Test text embedding
            test_embedding = self.text_embeddings_lc.embed_query("test connection")
            if test_embedding and len(test_embedding) > 0:
                print("✅ LangChain connection test successful")
            else:
                raise Exception("Empty embedding returned")
        except Exception as e:
            raise Exception(f"LangChain connection test failed: {e}")
    
    def analyze_image_with_nova_pro(self, image_base64: str, prompt: str = None) -> Dict[str, Any]:
        """Analyze image using LangChain ChatBedrock with Nova Pro."""
        if not self.enabled:
            return {"error": "LangChain service not enabled", "success": False}
        
        if not prompt:
            prompt = "Describe this image in detail, including objects, colors, setting, mood, and any text visible. Be specific and descriptive."
        
        try:
            # Create message with image using LangChain
            message = HumanMessage(
                content=[
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                    }
                ]
            )
            
            print(f"🔄 Trying Nova Pro with LangChain: {self.vision_model}")
            
            # Invoke model using LangChain
            response = self.vision_model_lc.invoke([message])
            
            description = response.content
            
            print(f"🖼️ LangChain Nova Pro image analysis successful: {description[:100]}...")
            
            return {
                "description": description,
                "model": f"langchain-nova-pro ({self.vision_model})",
                "success": True,
                "usage": getattr(response, 'usage_metadata', {}) if hasattr(response, 'usage_metadata') else {}
            }
            
        except Exception as e:
            print(f"⚠️ LangChain Nova Pro failed: {e}")
            # Fallback to Claude Haiku
            return self.analyze_image_with_claude_haiku(image_base64, prompt)
    
    def analyze_image_with_claude_haiku(self, image_base64: str, prompt: str) -> Dict[str, Any]:
        """Fallback image analysis using LangChain with Claude Haiku."""
        try:
            # Create Claude model instance
            claude_model = ChatBedrock(
                model_id="anthropic.claude-3-haiku-20240307-v1:0",
                region_name=self.region,
                model_kwargs={
                    "max_tokens": 1000,
                    "temperature": 0.1
                }
            )
            
            message = HumanMessage(
                content=[
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                    }
                ]
            )
            
            response = claude_model.invoke([message])
            description = response.content
            
            print(f"🖼️ LangChain Claude 3 Haiku fallback analysis: {description[:100]}...")
            
            return {
                "description": description,
                "model": "langchain-claude-3-haiku (fallback)",
                "success": True
            }
            
        except Exception as e:
            print(f"❌ LangChain Claude Haiku fallback also failed: {e}")
            return {
                "description": "Image analysis failed - visual content processed via multimodal embedding only",
                "model": "error",
                "success": False,
                "error": str(e)
            }
    
    def analyze_image(self, image_base64: str, prompt: str = None) -> Dict[str, Any]:
        """Main image analysis method using LangChain."""
        return self.analyze_image_with_nova_pro(image_base64, prompt)
    
    def generate_title_and_summary_from_image(self, image_base64: str) -> Dict[str, str]:
        """Generate title and summary from image using LangChain with prompt templates."""
        if not self.enabled:
            return {
                "title": "Untitled Image",
                "summary": "LangChain service not available",
                "source": "fallback"
            }
        
        try:
            # Use LangChain prompt template for better structure
            prompt_template = ChatPromptTemplate.from_messages([
                ("human", [
                    {"type": "text", "text": """Analyze this image and provide:
1. A short, descriptive title (5-8 words max)
2. A detailed summary describing what you see

Format your response exactly as:
TITLE: [your title here]
SUMMARY: [your detailed summary here]"""},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                    }
                ])
            ])
            
            # Create chain
            chain = prompt_template | self.vision_model_lc
            
            # Invoke chain
            response = chain.invoke({})
            
            description = response.content
            
            # Extract title and summary
            title = self._extract_title_from_response(description)
            summary = self._extract_summary_from_response(description)
            
            return {
                "title": title,
                "summary": summary,
                "source": f"langchain-{self.vision_model}",
                "usage": getattr(response, 'usage_metadata', {}) if hasattr(response, 'usage_metadata') else {}
            }
            
        except Exception as e:
            print(f"❌ LangChain title/summary generation error: {e}")
            return {
                "title": "Untitled Image",
                "summary": f"LangChain processing error: {str(e)}",
                "source": "error"
            }
    
    def _extract_title_from_response(self, response: str) -> str:
        """Extract title from structured AI response."""
        # Look for TITLE: pattern
        title_match = re.search(r'TITLE:\s*(.+?)(?:\n|SUMMARY:|$)', response, re.IGNORECASE)
        if title_match:
            title = title_match.group(1).strip()
            # Clean up and limit length
            title = re.sub(r'^["\']|["\']$', '', title)  # Remove quotes
            return title[:100] if title else "Untitled Image"
        
        # Fallback: use first sentence or first 50 characters
        first_sentence = response.split('.')[0].strip()
        return first_sentence[:50] + "..." if len(first_sentence) > 50 else first_sentence
    
    def _extract_summary_from_response(self, response: str) -> str:
        """Extract summary from structured AI response."""
        # Look for SUMMARY: pattern
        summary_match = re.search(r'SUMMARY:\s*(.+)', response, re.IGNORECASE | re.DOTALL)
        if summary_match:
            return summary_match.group(1).strip()
        
        # Fallback: use entire response if no structure found
        return response.strip()
    
    def enhance_user_content(self, title: str, summary: str, ai_descriptions: List[str]) -> Dict[str, str]:
        """Enhance user-provided title and summary with AI insights."""
        enhanced_title = title
        enhanced_summary = summary
        
        if ai_descriptions:
            # Extract key visual elements from AI descriptions
            visual_elements = self._extract_key_elements(ai_descriptions[0])
            
            # Enhance title with key visual elements (if not too long)
            if visual_elements and len(title) < 50:
                enhanced_title = f"{title} - {visual_elements}"
            
            # Enhance summary with AI description
            if summary:
                enhanced_summary = f"{summary}. Visual elements: {ai_descriptions[0][:200]}..."
            else:
                enhanced_summary = ai_descriptions[0]
        
        return {
            "enhanced_title": enhanced_title,
            "enhanced_summary": enhanced_summary
        }
    
    def _extract_key_elements(self, description: str) -> str:
        """Extract key visual elements for title enhancement."""
        keywords = []
        
        # Look for common visual elements
        visual_patterns = [
            r'\b(sunset|sunrise|beach|ocean|mountain|forest|city|building)\b',
            r'\b(beautiful|stunning|vibrant|colorful|peaceful|dramatic)\b',
            r'\b(blue|red|orange|green|yellow|purple|pink)\s+(?:sky|water|light)',
        ]
        
        for pattern in visual_patterns:
            matches = re.findall(pattern, description.lower())
            keywords.extend(matches[:2])
        
        if keywords:
            return " ".join(keywords[:3]).title()
        
        return ""
    
    def generate_embedding(self, text: str) -> List[float]:
        """Generate text-only embedding using LangChain BedrockEmbeddings."""
        if not self.enabled or not text or not text.strip():
            return self._generate_fallback_embedding(text)
        
        try:
            # Use LangChain for text embeddings
            embedding = self.text_embeddings_lc.embed_query(text[:30000])
            
            if embedding and len(embedding) > 0:
                print(f"✅ Generated LangChain text embedding (dimensions: {len(embedding)})")
                return embedding
            else:
                return self._generate_fallback_embedding(text)
                
        except Exception as e:
            print(f"⚠️ LangChain text embedding error: {e}")
            return self._generate_fallback_embedding(text)
    
    def generate_multimodal_embedding(self, text: str, image_base64: str) -> List[float]:
        """Generate multimodal embedding using direct boto3 (LangChain doesn't support this yet)."""
        if not self.enabled:
            return self._generate_fallback_embedding(f"multimodal_{text[:50]}")
        
        try:
            # Use direct boto3 for multimodal embeddings (LangChain doesn't support this yet)
            embedding = self._generate_multimodal_embedding_internal(
                text=text,
                image_base64=image_base64
            )
            
            if embedding and len(embedding) > 0:
                print(f"✅ Generated Titan Multimodal G1 embedding via direct API (dimensions: {len(embedding)})")
                return embedding
            else:
                print("⚠️ Multimodal embedding failed, using LangChain text-only")
                return self.generate_embedding(text)
                
        except Exception as e:
            print(f"⚠️ Multimodal embedding error: {e}")
            return self.generate_embedding(text)
    
    def generate_image_only_embedding(self, image_base64: str) -> List[float]:
        """Generate embedding from image only using direct boto3."""
        if not self.enabled:
            return self._generate_fallback_embedding("image_only")
        
        try:
            # Use direct boto3 for image-only embeddings
            embedding = self._generate_multimodal_embedding_internal(
                text=None,
                image_base64=image_base64
            )
            
            if embedding and len(embedding) > 0:
                print(f"✅ Generated Titan Multimodal G1 image-only embedding via direct API (dimensions: {len(embedding)})")
                return embedding
            else:
                return self._generate_fallback_embedding("image_only")
                
        except Exception as e:
            print(f"⚠️ Image-only embedding error: {e}")
            return self._generate_fallback_embedding("image_only")
    
    def _generate_multimodal_embedding_internal(self, text: str = None, image_base64: str = None) -> List[float]:
        """Generate multimodal embedding via direct boto3 (same as original service)."""
        if not text and not image_base64:
            raise ValueError("At least text or image must be provided")
        
        body_content = {}
        
        if text:
            body_content["inputText"] = text[:30000]
        
        if image_base64:
            body_content["inputImage"] = image_base64
        
        # Titan Multimodal G1 specific configuration
        body_content["embeddingConfig"] = {
            "outputEmbeddingLength": 1024  # G1 supports 256, 384, or 1024
        }
        
        body = json.dumps(body_content)
        
        response = self.bedrock_runtime.invoke_model(
            body=body,
            modelId=self.multimodal_embedding_model,  # amazon.titan-multimodal-embed-g1:0
            accept='application/json',
            contentType='application/json'
        )
        
        response_body = json.loads(response.get('body').read())
        return response_body.get('embedding', [])
    
    def _generate_fallback_embedding(self, text: str) -> List[float]:
        """Generate deterministic fallback embedding."""
        seed = abs(hash(text)) % 10000
        random.seed(seed)
        dims = int(os.getenv("VECTOR_DIMS", "1024"))
        embedding = [random.uniform(-0.1, 0.1) for _ in range(dims)]
        print(f"🔄 Generated LangChain fallback embedding ({dims}D)")
        return embedding
    
    def get_status(self):
        """Get service status for debugging."""
        return {
            "enabled": self.enabled,
            "langchain_available": self.langchain_available,
            "region": self.region,
            "text_model": self.text_embedding_model,
            "multimodal_model": self.multimodal_embedding_model,
            "vision_model": self.vision_model,
            "models_info": {
                "text_embedding": "Amazon Titan Text Embeddings V2 (via LangChain)",
                "multimodal_embedding": "Amazon Titan Multimodal Embeddings G1 (via direct boto3)", 
                "vision_analysis": f"Amazon Nova Pro (via LangChain, with Claude Haiku fallback)"
            },
            "capabilities": {
                "text_embedding": self.enabled,
                "multimodal_embedding": self.enabled,
                "image_analysis": self.enabled,
                "langchain_integration": self.langchain_available,
                "fallback_strategies": ["claude_haiku", "deterministic_embedding"]
            }
        }

# ...existing code...

   # ...existing code...

    def extract_tasks(self, prompt: str) -> Dict[str, Any]:
        """Extract tasks from content using LangChain ChatBedrock - TEXT ONLY."""
        if not self.enabled:
            return {"error": "LangChain service not enabled", "tasks": []}
        
        try:
            # Use text-only message (no image) for task extraction
            from langchain_core.messages import HumanMessage
            
            message = HumanMessage(content=prompt)
            
            # Invoke the vision model with text-only content
            response = self.vision_model_lc.invoke([message])
            
            # Parse the JSON response
            content = response.content.strip()
            print(f"🤖 LangChain AI response: {content[:200]}...")
            
            # Clean up the response to extract JSON
            if "```json" in content:
                start = content.find("```json") + 7
                end = content.find("```", start)
                content = content[start:end].strip()
            elif "```" in content:
                start = content.find("```") + 3
                end = content.find("```", start)
                content = content[start:end].strip()
            
            # Try to parse as JSON
            try:
                result = json.loads(content)
                print(f"✅ LangChain JSON parsing successful: {len(result.get('tasks', []))} tasks")
                return result
            except json.JSONDecodeError as e:
                print(f"⚠️ JSON parsing failed: {e}, attempting manual extraction")
                return self._manual_task_extraction(content)
                
        except Exception as e:
            print(f"❌ LangChain task extraction error: {e}")
            return {"error": str(e), "tasks": []}

# ...existing code...
    def _manual_task_extraction(self, content: str) -> Dict[str, Any]:
        """Manually extract tasks if JSON parsing fails."""
        tasks = []
        
        # Look for task-like patterns in the response
        lines = content.split('\n')
        current_task = {}
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Look for title patterns
            if any(keyword in line.lower() for keyword in ['title:', 'task:', 'action:', '1.', '2.', '-']):
                if current_task and current_task.get('title'):
                    tasks.append(current_task.copy())
                
                # Extract title from various formats
                if ':' in line:
                    title = line.split(':', 1)[1].strip()
                elif line.startswith(('1.', '2.', '3.', '-')):
                    title = line[2:].strip() if line.startswith(('1.', '2.', '3.')) else line[1:].strip()
                else:
                    title = line
                
                current_task = {
                    "title": title,
                    "category": "work",
                    "priority": "medium",
                    "confidence": 0.7
                }
            
            # Look for other fields
            elif current_task and 'description:' in line.lower():
                current_task["description"] = line.split(':', 1)[1].strip()
            elif current_task and 'category:' in line.lower():
                current_task["category"] = line.split(':', 1)[1].strip().lower()
            elif current_task and 'priority:' in line.lower():
                current_task["priority"] = line.split(':', 1)[1].strip().lower()
            elif current_task and 'due' in line.lower() and any(word in line.lower() for word in ['date', 'by', 'before']):
                # Try to extract date
                date_match = re.search(r'\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}|tomorrow|next week', line.lower())
                if date_match:
                    current_task["due_date"] = date_match.group(0)
        
        # Add the last task
        if current_task and current_task.get('title'):
            tasks.append(current_task)
        
        print(f"🔄 Manual extraction found {len(tasks)} tasks")
        return {"tasks": tasks}

# ...existing code...
# Global instance
langchain_bedrock_service = LangChainBedrockService()