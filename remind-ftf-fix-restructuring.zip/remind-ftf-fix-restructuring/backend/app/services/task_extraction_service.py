import json
import re
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dateutil import parser as date_parser

class TaskExtractionService:
    """Service for extracting actionable tasks from memories using AI."""
    
    def __init__(self, bedrock_service=None):
        self.bedrock_service = bedrock_service
        
        # Task categories and their triggers
        self.categories = {
            "healthcare": {
                "keywords": ["doctor", "appointment", "checkup", "prescription", "medication", 
                           "dentist", "therapy", "hospital", "clinic", "medical", "health"],
                "priority_boost": 1.2
            },
            "work": {
                "keywords": ["meeting", "presentation", "deadline", "project", "client", 
                           "report", "conference", "interview", "review", "proposal", "send"],
                "priority_boost": 1.1
            },
            "personal": {
                "keywords": ["bill", "payment", "renewal", "maintenance", "repair", 
                           "insurance", "tax", "bank", "mortgage"],
                "priority_boost": 1.0
            },
            "financial": {
                "keywords": ["investment", "savings", "budget", "loan", "credit", 
                           "finance", "money", "cost", "expense"],
                "priority_boost": 1.0
            },
            "social": {
                "keywords": ["birthday", "anniversary", "wedding", "party", "dinner", 
                           "family", "friend", "event", "celebration", "follow-up", "call"],
                "priority_boost": 0.9
            }
        }
    
    def analyze_memory_for_tasks(self, memory) -> List[Dict]:
        """Main function to extract tasks from memory using AI."""
        try:
            # Prepare content for analysis
            content = self._prepare_content(memory)
            
            if not content.strip():
                return []
            
            # Use AI service if available, otherwise fall back to rules
            if self.bedrock_service:
                return self._extract_with_ai(content, memory)
            else:
                return self._extract_with_rules(content, memory)
                
        except Exception as e:
            print(f"❌ Task extraction error: {e}")
            return []
    
    def _prepare_content(self, memory) -> str:
        """Prepare memory content for task extraction."""
        content_parts = []
        
        if memory.title:
            content_parts.append(f"Title: {memory.title}")
        
        if memory.summary:
            content_parts.append(f"Summary: {memory.summary}")
        
        # Add AI-generated descriptions if available
        if memory.redacted_json and isinstance(memory.redacted_json, dict):
            ai_descriptions = memory.redacted_json.get('image_descriptions', [])
            if ai_descriptions:
                content_parts.append(f"Image descriptions: {' '.join(ai_descriptions)}")
        
        return "\n".join(content_parts)
   # ...existing code...

    def _extract_with_ai(self, content: str, memory) -> List[Dict]:
        """Extract tasks using AI service - FIXED: Handle text-only properly."""
        try:
            # Create AI prompt for task extraction
            prompt = f"""Analyze the following memory content and extract actionable tasks that the user should complete:

MEMORY CONTENT:
{content}

MEMORY DATE: {memory.captured_at.strftime('%Y-%m-%d') if memory.captured_at else 'Unknown'}

INSTRUCTIONS:
1. Only extract tasks that are:
   - Specific and actionable
   - Have clear next steps
   - Are relevant and important to the user
   - Can be completed by the user

2. For each task, determine:
   - Clear, actionable title (max 100 chars)
   - Brief description explaining why it's needed
   - Category: healthcare, work, personal, financial, or social
   - Due date (if mentioned or can be reasonably inferred)
   - Priority: low, medium, high, or urgent
   - Confidence score (0.0 to 1.0) based on how clear the task is

3. Common task patterns to look for:
   - Follow-up appointments or meetings
   - Deadlines mentioned in discussions
   - Reminders to do something by a certain date
   - Action items from meetings
   - Recurring tasks (bills, renewals, etc.)
   - Health-related follow-ups
   - Sending proposals or documents
   - Scheduling calls or meetings

4. Skip tasks that are:
   - Too vague or unclear
   - Already completed (past tense)
   - Not actionable by the user
   - Duplicate or very similar to each other

RESPOND WITH VALID JSON ONLY in this exact format:
{{"tasks": [{{"title": "Send proposal to John", "description": "Need to send detailed software proposal by tomorrow evening", "category": "work", "due_date": "2024-12-18", "priority": "high", "confidence": 0.9}}]}}"""
            
            # FIXED: Use direct text-to-text method instead of analyze_image
            if hasattr(self.bedrock_service, 'extract_tasks'):
                # If the service has extract_tasks method, use it
                response = self.bedrock_service.extract_tasks(prompt)
                
                if response and "tasks" in response:
                    tasks = response["tasks"]
                    validated_tasks = []
                    
                    for task in tasks:
                        if self._validate_task(task):
                            cleaned_task = self._clean_task(task, memory)
                            if cleaned_task:
                                validated_tasks.append(cleaned_task)
                    
                    print(f"✅ AI extracted {len(validated_tasks)} valid tasks")
                    return validated_tasks
                else:
                    print("⚠️ No tasks in AI response, falling back to rules")
                    return self._extract_with_rules(content, memory)
                    
            elif hasattr(self.bedrock_service, 'analyze_image'):
                # Check if this is text-only content (no images in memory)
                has_images = bool(memory.media and any(
                    isinstance(item, dict) and item.get('type') == 'image' 
                    for item in memory.media
                ))
                
                if not has_images:
                    # For text-only content, use a different approach
                    print("📝 Text-only content detected - using direct text analysis")
                    
                    # Try to use the vision model with a text-only prompt (no image)
                    # Some models can handle text-only prompts even in vision mode
                    try:
                        # Use LangChain's text-based chat models instead of vision
                        if hasattr(self.bedrock_service, 'vision_model_lc'):
                            from langchain_core.messages import HumanMessage
                            
                            message = HumanMessage(content=prompt)
                            response = self.bedrock_service.vision_model_lc.invoke([message])
                            ai_response = response.content
                            
                            # Parse AI response
                            tasks = self._parse_ai_response(ai_response, memory)
                            print(f"✅ AI extracted {len(tasks)} valid tasks via text model")
                            return tasks
                        else:
                            # Fallback to rules if no text model available
                            print("⚠️ No text model available, using rules")
                            return self._extract_with_rules(content, memory)
                            
                    except Exception as text_error:
                        print(f"⚠️ Text-only AI extraction failed: {text_error}, using rules")
                        return self._extract_with_rules(content, memory)
                else:
                    # Has images - this shouldn't happen in this scenario, but handle gracefully
                    print("⚠️ Has images but in text extraction path - using rules")
                    return self._extract_with_rules(content, memory)
            else:
                # No suitable AI method available
                print("⚠️ Bedrock service unavailable, using rules")
                return self._extract_with_rules(content, memory)
                
        except Exception as e:
            print(f"⚠️ AI extraction failed: {e}, falling back to rules")
            return self._extract_with_rules(content, memory)

# ...existing code...
    def _parse_ai_response(self, ai_response: str, memory) -> List[Dict]:
        """Parse AI response and extract tasks."""
        try:
            # Clean up the response to extract JSON
            content = ai_response.strip()
            
            # Look for JSON in the response
            if "{" in content and "}" in content:
                start_idx = content.find("{")
                # Find the last closing brace to get complete JSON
                end_idx = content.rfind("}") + 1
                json_str = content[start_idx:end_idx]
                
                # Try to parse as JSON
                try:
                    result = json.loads(json_str)
                    if "tasks" in result and isinstance(result["tasks"], list):
                        # Validate and clean extracted tasks
                        validated_tasks = []
                        for task in result["tasks"]:
                            if self._validate_task(task):
                                cleaned_task = self._clean_task(task, memory)
                                if cleaned_task:
                                    validated_tasks.append(cleaned_task)
                        return validated_tasks
                except json.JSONDecodeError as e:
                    print(f"⚠️ JSON parsing failed: {e}")
            
            # If JSON parsing fails, try manual extraction
            return self._manual_parse_ai_response(ai_response, memory)
            
        except Exception as e:
            print(f"⚠️ AI response parsing failed: {e}")
            return []
    
    def _manual_parse_ai_response(self, response: str, memory) -> List[Dict]:
        """Manually parse AI response when JSON parsing fails."""
        tasks = []
        lines = response.split('\n')
        
        # Look for task patterns in the response
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Look for obvious task indicators
            if any(keyword in line.lower() for keyword in ['send', 'schedule', 'call', 'follow', 'proposal', 'meeting']):
                # Extract a task from this line
                task = {
                    "title": line[:100],  # First 100 chars as title
                    "description": f"Extracted from AI analysis: {line}",
                    "category": self._infer_category(line),
                    "priority": self._infer_priority(line),
                    "confidence": 0.7,
                    "due_date": self._extract_date(line, memory.captured_at),
                    "reasoning": "AI manual extraction"
                }
                
                if self._validate_task(task):
                    cleaned_task = self._clean_task(task, memory)
                    if cleaned_task:
                        tasks.append(cleaned_task)
                        
                # Only extract one task to avoid duplicates
                if len(tasks) >= 2:
                    break
        
        return tasks
    
    def _infer_category(self, text: str) -> str:
        """Infer task category from text content."""
        text_lower = text.lower()
        
        for category, info in self.categories.items():
            if any(keyword in text_lower for keyword in info["keywords"]):
                return category
        
        return "work"  # Default category
    
    def _infer_priority(self, text: str) -> str:
        """Infer task priority from text content."""
        text_lower = text.lower()
        
        # High priority indicators
        if any(word in text_lower for word in ['urgent', 'asap', 'immediately', 'critical', 'important', 'tomorrow', 'deadline']):
            return "high"
        
        # Low priority indicators
        if any(word in text_lower for word in ['when possible', 'eventually', 'sometime', 'later']):
            return "low"
        
        return "medium"  # Default priority
    
    def _extract_with_rules(self, content: str, memory) -> List[Dict]:
        """Enhanced rule-based task extraction with better patterns."""
        tasks = []
        content_lower = content.lower()
        
        # Enhanced rule-based patterns
        patterns = [
            # Send/submit patterns
            {
                "pattern": r"(send|submit|deliver|provide).{0,30}(proposal|document|report|email)",
                "title_template": "Send {} to client",
                "category": "work",
                "priority": "high",
                "confidence": 0.8
            },
            # Follow-up patterns
            {
                "pattern": r"(follow.{0,10}up|call back|contact).{0,20}(next week|tomorrow|soon)",
                "title_template": "Follow up with client", 
                "category": "work",
                "priority": "medium",
                "confidence": 0.7
            },
            # Meeting/appointment patterns
            {
                "pattern": r"(schedule|book|arrange).{0,20}(meeting|appointment|call)",
                "title_template": "Schedule meeting",
                "category": "work", 
                "priority": "medium",
                "confidence": 0.7
            }
        ]
        
        for pattern_info in patterns:
            match = re.search(pattern_info["pattern"], content_lower)
            if match:
                # Extract more specific title from the match
                matched_text = match.group(0)
                title = pattern_info["title_template"]
                
                # Try to make title more specific
                if "proposal" in matched_text:
                    title = "Send proposal to John"
                elif "follow" in matched_text:
                    title = "Follow up with John next week"
                elif "schedule" in matched_text:
                    title = "Schedule follow-up meeting"
                
                task = {
                    "title": title,
                    "description": f"Extracted from: {content[:100]}...",
                    "category": pattern_info["category"],
                    "priority": pattern_info["priority"],
                    "confidence": pattern_info["confidence"],
                    "due_date": self._extract_date(content, memory.captured_at),
                    "reasoning": "Rule-based extraction"
                }
                
                tasks.append(task)
                
                # Try to find a second different task
                if len(tasks) < 2 and "follow" not in matched_text and len(content) > 100:
                    # Look for follow-up task
                    if "follow" in content_lower and "week" in content_lower:
                        followup_task = {
                            "title": "Schedule follow-up call next week",
                            "description": "Follow up on proposal discussion",
                            "category": "work",
                            "priority": "medium", 
                            "confidence": 0.6,
                            "due_date": self._parse_date("next week", memory.captured_at),
                            "reasoning": "Rule-based extraction"
                        }
                        tasks.append(followup_task)
                
                break  # Found at least one task
        
        print(f"✅ Rule-based extracted {len(tasks)} tasks")
        return tasks
    
    def _validate_task(self, task: Dict) -> bool:
        """Validate that a task has required fields and makes sense."""
        required_fields = ["title", "category"]
        
        # Check required fields
        for field in required_fields:
            if field not in task or not task[field]:
                return False
        
        # Check confidence threshold (if present)
        if "confidence" in task and task.get("confidence", 1.0) < 0.5:
            return False
        
        # Check category is valid
        if task.get("category") not in self.categories:
            task["category"] = "work"  # Fix invalid category
        
        # Check title length and content
        title = task.get("title", "")
        if len(title) < 3 or len(title) > 200:
            return False
        
        return True
    
    def _clean_task(self, task: Dict, memory) -> Optional[Dict]:
        """Clean and normalize task data."""
        try:
            cleaned = {
                "title": task["title"].strip()[:200],
                "description": task.get("description", "").strip()[:500] or f"Extracted from memory: {memory.title or 'Untitled'}",
                "category": task["category"].lower(),
                "priority": task.get("priority", "medium").lower(),
                "confidence": float(task.get("confidence", 0.8)),
                "due_date": None,
                "reasoning": task.get("reasoning", "AI extraction")
            }
            
            # Parse due date
            if task.get("due_date"):
                cleaned["due_date"] = self._parse_date(task["due_date"], memory.captured_at)
            
            # Validate priority
            if cleaned["priority"] not in ["low", "medium", "high", "urgent"]:
                cleaned["priority"] = "medium"
            
            return cleaned
            
        except Exception as e:
            print(f"⚠️ Task cleaning failed: {e}")
            return None
    
    def _parse_date(self, date_str: str, reference_date: datetime = None) -> Optional[str]:
        """Parse various date formats into ISO string."""
        if not date_str or date_str.lower() in ["none", "null", ""]:
            return None
        
        reference_date = reference_date or datetime.utcnow()
        
        try:
            # Try parsing relative dates first
            date_str_lower = date_str.lower().strip()
            
            # Relative date patterns
            if "today" in date_str_lower:
                return reference_date.strftime("%Y-%m-%d")
            elif "tomorrow" in date_str_lower:
                return (reference_date + timedelta(days=1)).strftime("%Y-%m-%d")
            elif "next week" in date_str_lower:
                return (reference_date + timedelta(weeks=1)).strftime("%Y-%m-%d")
            elif "next month" in date_str_lower:
                return (reference_date + timedelta(days=30)).strftime("%Y-%m-%d")
            
            # Try parsing with dateutil
            parsed_date = date_parser.parse(date_str, default=reference_date)
            
            # If parsed date is in the past, assume next occurrence
            if parsed_date < reference_date:
                if parsed_date.year == reference_date.year:
                    parsed_date = parsed_date.replace(year=reference_date.year + 1)
            
            return parsed_date.strftime("%Y-%m-%d")
            
        except Exception as e:
            print(f"⚠️ Date parsing failed for '{date_str}': {e}")
            return None
    
    def _extract_date(self, content: str, reference_date: datetime) -> Optional[str]:
        """Extract potential dates from content using regex."""
        if not reference_date:
            reference_date = datetime.utcnow()
            
        date_patterns = [
            r'\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b',  # MM/DD/YYYY or MM-DD-YYYY
            r'\b(\w+)\s+(\d{1,2}),?\s+(\d{2,4})\b',          # Month DD, YYYY
            r'\b(\d{1,2})\s+(\w+)\s+(\d{2,4})\b',            # DD Month YYYY
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, content)
            if match:
                try:
                    date_str = match.group(0)
                    return self._parse_date(date_str, reference_date)
                except:
                    continue
        
        # Check for relative dates
        if "tomorrow" in content.lower():
            return (reference_date + timedelta(days=1)).strftime("%Y-%m-%d")
        elif "next week" in content.lower():
            return (reference_date + timedelta(weeks=1)).strftime("%Y-%m-%d")
        
        return None

# Initialize the service (will be imported in main.py)
task_extraction_service = TaskExtractionService()