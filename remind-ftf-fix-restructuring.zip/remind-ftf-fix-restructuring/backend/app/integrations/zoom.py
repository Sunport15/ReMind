import os
import requests
import base64
from datetime import datetime, timedelta
from typing import List, Dict, Any


def get_zoom_access_token(client_id: str, client_secret: str, account_id: str) -> str:
    """Get Zoom access token using client credentials."""
    url = "https://zoom.us/oauth/token"
    
    # Create basic auth header
    auth_str = f"{client_id}:{client_secret}"
    auth_bytes = auth_str.encode('ascii')
    auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
    
    headers = {
        "Authorization": f"Basic {auth_b64}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    data = {
        "grant_type": "account_credentials",
        "account_id": account_id
    }
    
    response = requests.post(url, headers=headers, data=data)
    response.raise_for_status()
    
    return response.json()["access_token"]


def get_meeting_details(token: str, meeting_id: str) -> Dict[str, Any]:
    """Get detailed meeting information including registrants."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # Get detailed meeting info
    meeting_url = f"https://api.zoom.us/v2/meetings/{meeting_id}"
    meeting_response = requests.get(meeting_url, headers=headers)
    
    if meeting_response.status_code != 200:
        return {}
    
    meeting_details = meeting_response.json()
    
    # Try to get registrants (if registration is enabled)
    registrants = []
    try:
        registrants_url = f"https://api.zoom.us/v2/meetings/{meeting_id}/registrants"
        registrants_response = requests.get(registrants_url, headers=headers)
        if registrants_response.status_code == 200:
            registrants = registrants_response.json().get("registrants", [])
    except:
        pass
    
    # Combine all the information
    enhanced_meeting = {
        **meeting_details,
        "registrants": registrants,
        "participants": [],  # Empty for future meetings
        "invitees": meeting_details.get("settings", {}).get("alternative_hosts", "").split(",") 
                   if meeting_details.get("settings", {}).get("alternative_hosts") else []
    }
    
    return enhanced_meeting


def extract_attendee_names(attendees: List[Dict[str, Any]]) -> List[str]:
    """Extract clean names from attendee data for better search."""
    names = []
    
    for attendee in attendees:
        email = attendee.get("email", "").strip()
        name = attendee.get("name", "").strip()
        
        if name:
            names.append(name)
        elif email:
            # Extract name from email (prakhardevs1@gmail.com -> prakhar)  
            name_part = email.split('@')[0]
            clean_name = ''.join([c for c in name_part if c.isalpha()])
            if clean_name:
                names.append(clean_name)
    
    return names


def format_meeting_datetime(start_time: str) -> str:
    """Format meeting start time for display."""
    try:
        dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        return dt.strftime("%B %d, %Y at %I:%M %p")
    except:
        return start_time


def format_attendee_list(attendees: List[Dict[str, Any]]) -> List[str]:
    """Format attendee list for summary display."""
    attendee_summary_parts = []
    
    for attendee in attendees:
        name = attendee.get("name", "").strip()
        email = attendee.get("email", "").strip()
        
        if name and email:
            attendee_summary_parts.append(f"{name} ({email})")
        elif email:
            # Extract display name from email for better readability
            display_name = email.split('@')[0]
            clean_display = ''.join([c for c in display_name if c.isalnum()])
            attendee_summary_parts.append(f"{clean_display} ({email})")
        elif name:
            attendee_summary_parts.append(name)
    
    return attendee_summary_parts


def create_meeting_summary(meeting_data: Dict[str, Any]) -> str:
    """Create a comprehensive, search-friendly summary for Zoom meetings."""
    title = meeting_data.get("title", "Zoom Meeting")
    description = meeting_data.get("description", "")
    
    summary_parts = [f"📅 Zoom Meeting: {title}"]
    
    # Add agenda/description
    if description:
        summary_parts.append(f"• 📋 Agenda: {description}")
    
    # Host information
    host_email = meeting_data.get("raw_zoom_data", {}).get("host_email")
    if host_email:
        summary_parts.append(f"• 👤 Host: {host_email}")
    
    # Meeting timing
    start_time = meeting_data.get("start_time")
    if start_time:
        formatted_date = format_meeting_datetime(start_time)
        summary_parts.append(f"• 🕐 Scheduled: {formatted_date}")
    
    # Duration
    duration = meeting_data.get("duration")
    if duration:
        summary_parts.append(f"• ⏱️ Duration: {duration} minutes")
    
    # Timezone
    timezone = meeting_data.get("timezone")
    if timezone:
        summary_parts.append(f"• 🌍 Timezone: {timezone}")
    
    # Enhanced attendee information for better search
    attendees = meeting_data.get("attendees", [])
    if attendees:
        attendee_names = extract_attendee_names(attendees)
        attendee_summary_parts = format_attendee_list(attendees)
        
        if attendee_summary_parts:
            summary_parts.append(f"• 👥 Invited Attendees ({len(attendees)}): {', '.join(attendee_summary_parts)}")
        
        # Add searchable names section for better semantic matching
        if attendee_names:
            summary_parts.append(f"• 🔍 Meeting with: {', '.join(attendee_names)}")
    
    # Meeting status
    status = meeting_data.get("status", "")
    if status:
        summary_parts.append(f"• 📊 Status: {status.title()}")
    
    # Meeting link
    meeting_link = meeting_data.get("meeting_link", "")
    if meeting_link:
        summary_parts.append(f"• 🔗 Join URL: {meeting_link}")
    
    # Password
    password = meeting_data.get("password", "")
    if password:
        summary_parts.append(f"• 🔑 Meeting Password: {password}")
    
    return '\n'.join(summary_parts)


def calculate_meeting_end_time(start_time: str, duration: int) -> str:
    """Calculate meeting end time from start time and duration."""
    if not start_time:
        return ""
    
    try:
        start_dt = datetime.fromisoformat(start_time.replace("Z", "+00:00"))
        end_dt = start_dt + timedelta(minutes=duration)
        return end_dt.isoformat()
    except:
        return ""


def extract_meeting_attendees(detailed_meeting: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract attendees from various sources in meeting details."""
    attendees = []
    
    # From registrants (future meetings might have these)
    for registrant in detailed_meeting.get("registrants", []):
        attendees.append({
            "name": f"{registrant.get('first_name', '')} {registrant.get('last_name', '')}".strip(),
            "email": registrant.get("email", ""),
            "type": "registrant",
            "status": registrant.get("status", "")
        })
    
    # From alternative hosts and invitees
    for host_email in detailed_meeting.get("invitees", []):
        if host_email.strip():
            attendees.append({
                "name": "",
                "email": host_email.strip(),
                "type": "alternative_host",
                "status": "invited"
            })
    
    # If no specific attendees found, try to extract from meeting settings
    if not attendees:
        settings = detailed_meeting.get("settings", {})
        if settings.get("alternative_hosts"):
            alt_hosts = settings.get("alternative_hosts", "").split(",")
            for host_email in alt_hosts:
                if host_email.strip():
                    attendees.append({
                        "name": "",
                        "email": host_email.strip(),
                        "type": "alternative_host",
                        "status": "invited"
                    })
    
    return attendees


def is_future_meeting(meeting: Dict[str, Any], time_threshold_hours: int = 2) -> bool:
    """Check if meeting is scheduled for the future."""
    start_time_str = meeting.get("start_time", "")
    if not start_time_str:
        return True  # Include meeting if we can't determine time
    
    try:
        start_time = datetime.fromisoformat(start_time_str.replace("Z", "+00:00"))
        now = datetime.utcnow()
        time_threshold = now - timedelta(hours=time_threshold_hours)
        return start_time > time_threshold
    except Exception as e:
        print(f"⚠️ Could not parse start time for meeting {meeting.get('id')}: {e}")
        return True  # Include meeting if we can't parse time


def build_meeting_data(meeting: Dict[str, Any], detailed_meeting: Dict[str, Any]) -> Dict[str, Any]:
    """Build structured meeting data from Zoom API responses."""
    meeting_id = str(meeting.get("id"))
    start_time = meeting.get("start_time", "")
    duration = meeting.get("duration", 0)
    end_time = calculate_meeting_end_time(start_time, duration)
    attendees = extract_meeting_attendees(detailed_meeting)
    
    meeting_data = {
        "id": meeting_id,
        "uuid": meeting.get("uuid", ""),
        "title": meeting.get("topic", "Zoom Meeting"),
        "description": meeting.get("agenda", ""),
        "start_time": start_time,
        "end_time": end_time,
        "duration": duration,
        "attendees": attendees,
        "meeting_link": meeting.get("join_url", ""),
        "host_id": meeting.get("host_id", ""),
        "created_at": meeting.get("created_at", ""),
        "timezone": meeting.get("timezone", ""),
        "meeting_type": meeting.get("type", 2),
        "status": meeting.get("status", "waiting"),
        "settings": detailed_meeting.get("settings", {}),
        "password": detailed_meeting.get("password", ""),
        "encrypted_password": detailed_meeting.get("encrypted_password", ""),
        "h323_password": detailed_meeting.get("h323_password", ""),
        "pstn_password": detailed_meeting.get("pstn_password", ""),
        "occurrences": detailed_meeting.get("occurrences", []),
        "tracking_fields": detailed_meeting.get("tracking_fields", []),
        "raw_zoom_data": detailed_meeting
    }
    
    # Generate the formatted summary
    meeting_data["formatted_summary"] = create_meeting_summary(meeting_data)
    
    return meeting_data


def get_future_zoom_meetings(client_id: str, client_secret: str, account_id: str) -> List[Dict[str, Any]]:
    """Fetch FUTURE Zoom meetings only - perfect for hackathon demo."""
    # Get access token
    token = get_zoom_access_token(client_id, client_secret, account_id)
    
    # Get meetings list - FETCH ONLY FUTURE MEETINGS
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    meetings_url = "https://api.zoom.us/v2/users/me/meetings"
    params = {
        "type": "scheduled",  # Only scheduled meetings (not past)
        "page_size": 50,      # Increased to get more meetings
        "page_number": 1      # First page
    }
    
    print(f"🔍 Fetching future scheduled meetings from Zoom API...")
    
    meetings_response = requests.get(meetings_url, headers=headers, params=params)
    meetings_response.raise_for_status()
    
    # Process meetings from the response
    meetings_data = meetings_response.json().get("meetings", [])
    
    # FILTER: Only include meetings that are in the future
    future_meetings = [
        meeting for meeting in meetings_data 
        if is_future_meeting(meeting)
    ]
    
    # Log filtering results
    for meeting in meetings_data:
        if is_future_meeting(meeting):
            print(f"✅ Including future meeting: {meeting.get('topic', 'Untitled')}")
        else:
            print(f"⏭️ Skipping past meeting: {meeting.get('topic', 'Untitled')}")
    
    print(f"📊 Filtered to {len(future_meetings)} future meetings out of {len(meetings_data)} total")
    
    # Process each future meeting
    results = []
    for meeting in future_meetings:
        meeting_id = str(meeting.get("id"))
        
        # Get enhanced details for each future meeting
        detailed_meeting = get_meeting_details(token, meeting_id)
        
        # Build structured meeting data
        meeting_data = build_meeting_data(meeting, detailed_meeting)
        results.append(meeting_data)
        
        print(f"📋 Processed future meeting: {meeting_data['title']} ({len(meeting_data['attendees'])} attendees)")
    
    print(f"✅ Completed processing {len(results)} future meetings")
    return results


# Alias for backward compatibility
get_zoom_meetings_with_details = get_future_zoom_meetings